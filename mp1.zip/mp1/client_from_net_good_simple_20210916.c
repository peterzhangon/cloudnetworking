#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>

int main(int argc, char *argv[]){

    char domain[] = "EOOPF263S8B-1.bns.bns";
	char *path = argv[1];
	
    int sock, len_recv;  
    char send_data[1024], recv_data[9999];
    struct sockaddr_in server_addr;
    struct hostent *host;
    FILE *fp;

    host = gethostbyname(domain);
	fprintf(stderr, "\n\ndomain: %s -> host:%s, path: %s\n", domain, host, path);
    if (NULL == host){
       herror("gethostbyname");
       exit(1);
    }

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1){
       perror("Socket");
       exit(1);
    }

    server_addr.sin_family = AF_INET;     
    server_addr.sin_port = htons(8001);
    server_addr.sin_addr = *((struct in_addr *)host->h_addr);
    bzero(&(server_addr.sin_zero),8); 

    printf("Connecting ...\n");
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) == -1){
       perror("Connect");
       exit(1); 
    }

	// Construct the request
	printf("Sending data ...\n");
    snprintf(send_data, sizeof(send_data), "GET /%s HTTP/1.1\r\nHost: /%s\r\n\r\n", path, domain);

    if(send(sock, send_data, strlen(send_data), 0)==-1){
        perror("send");
        exit(2); 
    }
    //printf("Data sent.\n");  

    fp = fopen("received_file","wb");

    printf("Recieving data...\n\n");
	int cnt = 0;
    while((len_recv = recv(sock, recv_data, 9999, 0)) > 0){

		fprintf(stderr, "\n\n++++++++++, cnt: %d\n", cnt);
        if(-1 == len_recv){
            perror("recieve");
            exit(3);
        }
        recv_data[len_recv] = '\0';

        fwrite(recv_data, len_recv, 1, fp);
        fprintf(stderr, "contents: %s", recv_data);
		//fprintf(stderr, "\n\n**********, cnt: %d\n", cnt);
		cnt++;
    }

    close(sock);
    fclose(fp);

	fprintf(stderr, "\n\n Done done. line = %d cnt = %d\n", __LINE__, cnt);
    return 0;
}
