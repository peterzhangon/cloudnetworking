/*
** client.c -- a stream socket client demo
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>

#include <arpa/inet.h>


#define MAXDATASIZE 1000 // max number of bytes we can get at once 

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
	if (sa->sa_family == AF_INET) {
		return &(((struct sockaddr_in*)sa)->sin_addr);
	}

	return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

// Find the first string before a specific chart
void find_str(char *pSource, char *pTarget, char divider)
{
	//fprintf(stderr, "\n\n******* Begin to find :%s, %c\n", pSource, divider);
	int max = strlen(pSource) - 1;
	for (int i = 0; i < strlen(pSource); i++)
	{
		//fprintf(stderr, "*** loop: len: %d %c %d\n", strlen(pSource), pSource[i], i);
		if (divider == pSource[i])
		{
			pTarget[i] = '\0';
			//fprintf(stderr, "*** Found a string: %d %s\n", strlen(pTarget), pTarget);
			return;
		}
		if ((divider == pSource[i]) || (i >= max))
		{
			pTarget[i++] = pSource[i];
			pTarget[i] = '\0';
			//fprintf(stderr, "--- Found a string: %d %s\n", strlen(pTarget), pTarget);
			return;
		}
		//fprintf(stderr, "*** end loop\n");
		pTarget[i] = pSource[i];
	}
}

// http://hostname[:port]/path_to_file
int main(int argc, char *argv[])
{
	int sockfd, num_bytes;  
	char rcv_data[MAXDATASIZE];
	char send_data[MAXDATASIZE];
	struct addrinfo hints, *servinfo, *p;
	int rv;
	char s[INET6_ADDRSTRLEN];
	char host_name[100];
	char port_number[20];
	char http_const[8] = "http://";
	char contents_NotFound[] = "FILENOTFOUND";
	char contents_InvalidInput[] = "INVALIDPROTOCOL";
	char contents_unusable[] = "NOCONNECTION";
	char *pPath = NULL;
	FILE *fp;
	int len_http = 7;
	char *pBase = NULL;
	int total_len = strlen(argv[1]);
	char *pInput = argv[1];

	if (argc != 2) {
	    fprintf(stderr,"usage: client http:host[port]file\n");
	    exit(1);
	}
	fp = fopen("output","wb");
	// Get the hostname, port, and path from the user input
    // http://hostname[:port]/path_to_file
	// fprintf(stderr, "pInput is: [%s], line: %d\n", pInput, __LINE__);
	
	// part 1: Check http_const
	if (0 != strncmp(pInput, http_const, len_http))
	{
		//fprintf(stderr, "**************Wrong http://\n");
		fwrite(contents_InvalidInput, strlen(contents_InvalidInput), 1, fp);
		fclose(fp);
		close(sockfd);
		return 3;
	}
	pBase = pInput + len_http;

	// Part 2: get the hostname
	find_str(pBase, host_name, ':');
	// Case 1: it does NOT has a port number
	if (strlen(pBase) == strlen(host_name))
	{
		find_str(pBase, host_name, '/');
		pPath = pBase + strlen(host_name);
		strcpy(port_number, "80");
		//fprintf(stderr, "case 1: [%s], [%s], [%s]\n", host_name, port_number, pPath);
	}
	// Case 2: it has a port number
	else
	{
		pBase = pBase + strlen(host_name) + 1;
		find_str(pBase, port_number, '/');
		pPath = pBase + strlen(port_number);
		//fprintf(stderr, "case 2: [%s], [%s], [%s]\n", host_name, port_number, pPath);
	}

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	if ((rv = getaddrinfo(host_name, port_number, &hints, &servinfo)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		fwrite(contents_unusable, strlen(contents_unusable), 1, fp);
		fclose(fp);
		close(sockfd);
		return 1;
	}

	// loop through all the results and connect to the first we can
	for(p = servinfo; p != NULL; p = p->ai_next) {
		if ((sockfd = socket(p->ai_family, p->ai_socktype,
				p->ai_protocol)) == -1) {
			perror("client: socket");
			continue;
		}

		if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("client: connect");
			continue;
		}

		break;
	}

	if (p == NULL) {
		fprintf(stderr, "client: failed to connect\n");
		fwrite(contents_unusable, strlen(contents_unusable), 1, fp);
		fclose(fp);
		close(sockfd);
		return 2;
	}

	inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr),
			s, sizeof s);
	//printf("client: connecting to %s\n", s);
    
    snprintf(send_data, sizeof(send_data), "GET /%s HTTP/1.1\r\nHost: /%s\r\n\r\n", pPath, host_name);

    if(send(sockfd, send_data, strlen(send_data), 0) == -1){
		fprintf(stderr, "send error.\n");
		fwrite(contents_unusable, strlen(contents_unusable), 1, fp);
		fclose(fp);
		close(sockfd);
        exit(2); 
    }
	
	freeaddrinfo(servinfo); // all done with this structure

	num_bytes = recv(sockfd, rcv_data, MAXDATASIZE - 1, 0);

	if (strstr(rcv_data, "200 OK")) 
	{
		//fprintf(stderr, "Good response : %s\n", rcv_data);
	}
	if (strstr(rcv_data, "404 File not found")) 
	{
		fprintf(stderr, "404 Not Found response.\n");
		fwrite(contents_NotFound, strlen(contents_NotFound), 1, fp);
		fclose(fp);
		close(sockfd);
		return 3;
	}
	int cnt = 0;
    while((num_bytes = recv(sockfd, rcv_data, MAXDATASIZE - 1, 0)) > 0){

		//fprintf(stderr, "\n\n++++++++++, cnt: %d\n", cnt);
        if(-1 == num_bytes){
            perror("recieve");
            exit(3);
        }
        rcv_data[num_bytes] = '\0';
        fwrite(rcv_data, num_bytes, 1, fp);
        //fprintf(stderr, "contents: %s", rcv_data);
		cnt++;
		//fprintf(stderr, "\n\n**********, cnt: %d\n", cnt);
    }

	fprintf(stderr, "\n\n Done done.\n");
    fclose(fp);
	close(sockfd);

	return 0;
}

