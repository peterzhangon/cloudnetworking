https://stackoverflow.com/questions/22077802/simple-c-example-of-doing-an-http-post-and-consuming-the-response
https://www.theinsanetechie.in/2014/02/a-simple-http-client-and-server-in-c.html

int main(int argc, char *argv[])
{
    char pszRequest[100]= {0};
    char pszResourcePath[]="2016/04/create-xml-request-in-c-for-server.html";
    char pszHostAddress[]="www.aticleworld.com";
    sprintf(pszRequest, "GET /%s HTTP/1.1\r\nHost: %s\r\nContent-Type: text/plain\r\n\r\n", pszResourcePath, pszHostAddress);
    printf("Created Get Request is below:\n\n\n");
    printf("%s", pszRequest);
    return 0;
}

Phase 1:
++++++++++++++++++++++++++
server:
./server
client:
./client localhost
./client 127.0.0.1


Phase 2:
++++++++++++++++++++++++++
No need to consider the server, only consider to develop a client which supports GET method

server:
use cmd to run:
-------------------
cd C:\peter\book\network
python -m http.server 8001

We have a file ./peter.txt
We have a file doc/peter.txt
./doc/peter.txt
python -m http.server 8001
start a server

client:
ping 10.254.164.138 
cd /home/paizha/code/git/net/mp01
ping EOOPF263S8B-1.bns.bns
correct:
./client peter.txt
./client doc/peter.txt
./client /doc/peter.txt
./client ./doc/peter.txt
wrong:
./client \peter.txt
./client \doc\peter.txt

ENV on the linux:
++++++++++++++++++++++++++

cd ~/code/git/rfrswap/analyticsrs
source ./config/testenv.sh uat
cd /home/paizha/code/git/net/mp01

Local git bash:
++++++++++++++++++++++++++
ssh paizha@lvappi00729.bns


Win SCP
++++++++++++++++++++++++++
C:\peter\book\network\code\MP1\submit
/home/paizha/code/git/net/mp01

 

