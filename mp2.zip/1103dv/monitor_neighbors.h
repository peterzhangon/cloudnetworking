#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <sys/time.h>
#include <signal.h>
#include <unistd.h>
#include <stdbool.h> 


int gTestCaseId = 0;

// Debug print
unsigned int  gDbgRoute = 1;
unsigned int  gDbgStop = 2;
unsigned int  gDbgMsg = 4;
unsigned int  gDbgHeartBeat = 8;
unsigned int  gDbg = 5;

FILE *runingLogFile;
int globalMyID = 0;


// ********* orig begin *************
#define MAX_NODE_SIZE 256
#define MAX_PATH_NUM 200
#define MAX_PATH_SIZE 20


typedef struct RouteTableDV {
	int iSeq;
	int iRouteCosts[MAX_NODE_SIZE];
} RouteTableDV;

typedef struct NodeInfoDV {
	int  iCost;
	int  iDest;
	bool isActive;
	RouteTableDV *pRouteTable;
} NodeInfoDV;

//last time you heard from each node. TODO: you will want to monitor this
//in order to realize when a neighbor has gotten cut off from you.
struct timeval globalLastHeartbeat[MAX_NODE_SIZE];

//our all-purpose UDP socket, to be bound to 10.1.1.globalMyID, port 7777
int globalSocketUDP;
//pre-filled for sending to 10.1.1.0 - 255, port 7777
struct sockaddr_in globalNodeAddrs[MAX_NODE_SIZE];

// Here we have 256 at most
// The cost here is all the cost of the path
NodeInfoDV globalNodeInfoDV[MAX_NODE_SIZE];
// This is the practical cost between this node to each dest
int globalCosts[MAX_NODE_SIZE]; // PV


///////////// DV 
// record its own info
RouteTableDV globalLocalRouteTable;

int nConnectedNodes = 0;
int connectedNodes[MAX_NODE_SIZE];
int routeTableNeedUpdate = 1;
int updatingRouteTable = 0;


// My own log file
char buffer[2000];
char peterDebugBuffer[3000];
FILE *peterLogFile = NULL;
char logFileName[200];

void changeCost(unsigned short destID, unsigned int newCost);
void determineConnectedNodesDV ();
void findBestRouteToIDV(int i, int* pNext_hop_j, int* pMy_cost_i_via_j);
int reComputeRouteTableDV();
void forwardMessage(unsigned short destID, unsigned char * recvBuf,int bytesRecvd);
void sendMessage(int destID, unsigned char * recvBuf,int nBytes);

void logSend(const char* message, int dest, int nexthop);
void logForward(const char* message, int dest, int nexthop);
void logReceive(const char* message);
void logUnreachable(int dest);

void outputNodeInfo();

int dbg = 0;
void debug_stop() {
	if (0 == dbg) {
		return;
	}
	//fprintf(stderr, "\n**************** Begin to debug_stop *************");
	char * tmpFile = (char *)malloc(100);
	char * pid = (char *)malloc(100);

	sprintf(pid, "%d", getpid());
	// ********************* change to your own directory *****************
	sprintf(tmpFile, "/home/ec2-user/mp2/code/pid/pid_%s", pid);

	FILE *fp = fopen (tmpFile, "w+");
	fclose(fp);

	fprintf(stderr, "*** debug file = %s", tmpFile);
	int cnt = 0;
	fprintf(stderr, "\nPleasae remove the file %s to continue.", tmpFile);

	while (1) {
		if(access(tmpFile, F_OK) != 0)
		{
			fprintf(stderr, "\n%s does not exist, so continue the thread.", tmpFile);
			break;
		} else if (cnt >= 5000) {
			fprintf(stderr, "\n%s to be removed, so the current thread is blocked here.", tmpFile);
			cnt = 0;
		}
		cnt++;
		sleep(1);
		break;
	}

	fprintf(stderr, "\n**************** Begin to process the data via pid");
	free(tmpFile);
	free(pid);

}

// 1 - use pv
// 0 - use dv
// common
int usePV()
{
	if((5 != gTestCaseId) || ((8 != gTestCaseId)))
	{
		return 0;
	}
	return 0;
}

int cntFlush = 0;
void outputMsg(char * str)
{
	if ((gDbg & gDbgMsg) == 0)
	{
		return;
	}
	if(globalMyID > 3 || gTestCaseId != 5)
	{
		//return;
	}

	cntFlush++;
	//fprintf(stderr, "\n%d: %s", globalMyID, str);

	//fprintf(stderr, "\nstr: %s, File: %s, Line: %d", str,  __FILE__, __LINE__);
	time_t current_time;
	struct tm * time_info;
	char tmpTime[100];
	//fprintf(stderr, "\nFile: %s, Line: %d", __FILE__, __LINE__);

	time(&current_time);
	time_info = localtime(&current_time);

	strftime(tmpTime, 26, "%M:%S", time_info);

	// sprintf(peterDebugBuffer, "\n%ld_%s:%s", (long)getpid(), tmpTime, str);
	sprintf(peterDebugBuffer, "\n%s:%s", tmpTime, str);
	fwrite(peterDebugBuffer, 1, strlen(peterDebugBuffer), peterLogFile);
	if (cntFlush >= 100)
	{
		fflush(peterLogFile);
		cntFlush = 0;
	}
}

// common
void prepareLogFile()
{
	//fprintf(stderr, "\nprepareLogFile() File: %s, Line: %d", __FILE__, __LINE__);

	time_t seconds;
	//fprintf(stderr, "\nFile: %s, Line: %d", __FILE__, __LINE__);

	seconds = time(NULL);
	sprintf(logFileName, "./log/%ld_%d", seconds, globalMyID);
	//fprintf(stderr, "\nPeter's debug log file = %s", logFileName);
	peterLogFile = fopen(logFileName, "w");
	if (NULL == peterLogFile) {
		fprintf(stderr, "\nFailed to create the log file = %s", logFileName);
	} else {
		//fprintf(stderr, "\nSucceded to create the log file = %s", logFileName);
	}
	strcpy(peterDebugBuffer, "\nBegin the test.");
	fwrite(peterDebugBuffer, 1, strlen(peterDebugBuffer), peterLogFile);
	fflush(peterLogFile);
	
	sprintf(buffer, "My node id: [%d]", globalMyID);
	outputMsg(buffer);
}

// common
void setupruningLogFile(const char* fileName)
{
	sprintf(buffer, "Created the log file for the app.");
	outputMsg(buffer);

	runingLogFile = fopen(fileName, "w+"); 
}

// common
void parseCostperLine(char* str, int* pNodeId, int* pCcost)
{
	sprintf(buffer, "parseCostperLine() has been called.");
	outputMsg(buffer);

	int init_size = strlen(str);
	char delim[] = " \n";
	char *ptr1 = strtok(str, delim);
	char *ptr2 = strtok(NULL, delim);
	*pNodeId = atoi(ptr1);
	*pCcost = atoi(ptr2);

	//sprintf(buffer, "Line: %s -> %d %d\n", *pNodeId, *pCcost);
	//outputMsg(buffer);
}

// pv
void processInitCostFileDV(const char* fileName)
{

	sprintf(buffer, "processInitCostFileDV() has been called.");
	outputMsg(buffer);

	FILE* fp;
	char* line;
	size_t len = 0;
	ssize_t read;
	int nodeId, cost;

	fp = fopen(fileName, "r");
	if (fp == NULL){
		//fprintf(stderr, "\n\n **************** \npeter: %s, Line: %d\n", __FILE__, __LINE__);
 		fprintf(stderr, "Unable to read initial cost file: %s \n", fileName);
		exit(1);
	}

	while ((read = getline(&line, &len, fp)) != -1)
	{
		parseCostperLine(line,&nodeId, &cost);
		globalNodeInfoDV[nodeId].iCost = cost;
	}

	if (line)
	{
		free(line);
	}

	fclose(fp);
}

void processInitCostFile(const char* fileName)
{
	sprintf(buffer, "processInitCostFile() has been called.");
	outputMsg(buffer);

	if(usePV() == 1)
	{
		//
	}
	else
	{
		processInitCostFileDV(fileName);
	}
}


void initNodesDV()
{
	sprintf(buffer, "initNodesDV() has been called.");
	outputMsg(buffer);


	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		globalNodeInfoDV[i].iCost = 1;
		globalNodeInfoDV[i].iDest = -1;
		globalNodeInfoDV[i].isActive = false;
		globalNodeInfoDV[i].pRouteTable = NULL;
	}
	globalNodeInfoDV[globalMyID].iCost = 0;
	globalNodeInfoDV[globalMyID].iDest = globalMyID;
	globalNodeInfoDV[globalMyID].isActive = true;
}

void outputNodeInfo();

//common
void changeCost(unsigned short destID, unsigned int newCost){
	sprintf(buffer, "mod cost: destID = %d, cost = %d", destID, newCost);
	outputMsg(buffer);
	globalNodeInfoDV[destID].iCost = newCost;
}


//////////////////////////////////////////////////

void initCostsDV()
{
	sprintf(buffer, "initCostsDV() has been called.");
	outputMsg(buffer);


	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		globalLocalRouteTable.iRouteCosts[i] = -1;
	}
	globalLocalRouteTable.iRouteCosts[globalMyID] = 0;
}

void outputRouteTableDV(RouteTableDV  * pRoutingTable,  int isSent)
{
	sprintf(buffer, "RoutingTable Info: Myid_%d isSend: %d, cost: %d, seq: %d", globalMyID, isSent, pRoutingTable->iRouteCosts, pRoutingTable->iSeq);
	outputMsg(buffer);
}

// Yes, this is terrible. It's also terrible that, in Linux, a socket
// can't receive broadcast packets unless it's bound to INADDR_ANY,
// which we can't do in this assignment.
void broadcastRouteTable()
{
	sprintf(buffer, "broadcastRouteTable() has been called.");
	outputMsg(buffer);

	routeTableNeedUpdate = 0;
	int len = 6 + sizeof(RouteTableDV);
	char sendBuf[len];

	strcpy(sendBuf, "routes");
	outputRouteTableDV(&globalLocalRouteTable, 1);

	memcpy(sendBuf + 6, &globalLocalRouteTable, sizeof(RouteTableDV));

	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		if (i != globalMyID)
		{
			sendto(globalSocketUDP, sendBuf, len, 0,
				  (struct sockaddr*)&globalNodeAddrs[i], sizeof(globalNodeAddrs[i]));
		}
	}
}


void* announceToNeighborsDV(void* unusedParam)
{
	sprintf(buffer, "announceToNeighborsDV() has been called.");
	outputMsg(buffer);

	struct timespec sleepFor;
	sleepFor.tv_sec = 0;
	sleepFor.tv_nsec = 300 * 1000 * 1000; //300 ms
	while(1)
	{
		broadcastRouteTable();
		nanosleep(&sleepFor, 0);
	}
}

//////
void* announceToNeighbors(void* unusedParam)
{
	sprintf(buffer, "announceToNeighbors() has been called.");
	outputMsg(buffer);

	if(usePV())
	{
		
	}
	else
	{
		announceToNeighborsDV(unusedParam);
	}

}

void listenForNeighborsDV()
{
	sprintf(buffer, "listenForNeighborsDV() has been called.");
	outputMsg(buffer);

	char fromAddr[100];
	struct sockaddr_in theirAddr;
	socklen_t theirAddrLen;
	unsigned char recvBuf[2500];

	//sprintf(buffer, "**** listenForNeighbors() is called before while(true) loop.");
	//outputMsg(buffer);

	int bytesRecvd;
	while(1)
	{
		int needToRecomputeRoute = 0;

		theirAddrLen = sizeof(theirAddr);
		if ((bytesRecvd = recvfrom(globalSocketUDP, recvBuf, 2000 , 0, 
					(struct sockaddr*)&theirAddr, &theirAddrLen)) == -1)
		{
			perror("\nconnectivity listener: recv from failed");
			exit(1);
		}

		inet_ntop(AF_INET, &theirAddr.sin_addr, fromAddr, 100);

		short int heardFrom = -1;

		if (strstr(fromAddr, "10.1.1."))
		{
			heardFrom = atoi(strchr(strchr(strchr(fromAddr,'.') + 1,'.') + 1,'.') + 1);

			// Done: this node can consider heardFrom to be directly connected to it; do any such logic now.

			// link status change detection
			bool status = globalNodeInfoDV[heardFrom].isActive;
			globalNodeInfoDV[heardFrom].isActive = true;
			if (!status)
			{
				needToRecomputeRoute = 1;
			}

			// Record that we heard from heardFrom just now.
			gettimeofday(&globalLastHeartbeat[heardFrom], 0);
		}

		// Is it a packet from the manager? (see mp2 specification for more details)
		// Send format: 'send'<4 ASCII bytes>, destID<net order 2 byte signed>, <some ASCII message>
		if (!strncmp(recvBuf, "send", 4))
		{
			sprintf(buffer, "Rcv a send: %d with bytes = %d", heardFrom, bytesRecvd);
			outputMsg(buffer);
			// Done to send the requested message to the requested destination node
			unsigned short *pDestID = (unsigned short *)&recvBuf[4];
			unsigned short destID = ntohs(*pDestID);
			char* message = (char*)&recvBuf[6];
			recvBuf[bytesRecvd] = '\0';
			if (-1 == heardFrom)
			{
				sendMessage(destID, recvBuf, bytesRecvd);
			}
			else if (destID == globalMyID)
			{
				logReceive(message);
			}
			else
			{
				forwardMessage(destID, recvBuf, bytesRecvd);
			}

		}
		//'cost'<4 ASCII bytes>, destID<net order 2 byte signed> newCost<net order 4 byte signed>
		else if (!strncmp(recvBuf, "cost", 4))
		{
			sprintf(buffer, "Rcv a cost: %d %d", heardFrom, bytesRecvd);
			outputMsg(buffer);
			// Done record the cost change (remember, the link might currently be down! in that case,
			// This is the new cost you should treat it as having once it comes back up.)
			unsigned short *pDestID = (unsigned short *)(recvBuf + 4);
			unsigned int *pNewCost = (unsigned int *)(recvBuf + 6);
			changeCost(ntohs(*pDestID), ntohl(*pNewCost));
			needToRecomputeRoute = 1;

		}
		// Done now check for the various types of packets you use in your own protocol
		// else if(!strncmp(recvBuf, "your other message types", ))
		else if (bytesRecvd >= 6 && !strncmp(recvBuf, "routes", 6))
		{
			sprintf(buffer, "Rcv a route: %d %d", heardFrom, bytesRecvd);
			outputMsg(buffer);
			//extract route_table
			RouteTableDV * pRouteTable = (RouteTableDV *)&recvBuf[6];
			outputRouteTableDV(pRouteTable, 0);
			NodeInfoDV fromNodeInfo = globalNodeInfoDV[heardFrom];
			RouteTableDV * oldRouteTable = fromNodeInfo.pRouteTable;

			if ((NULL != oldRouteTable) && (pRouteTable->iSeq == oldRouteTable->iSeq))
			{
				//already seen this info
				sprintf(buffer, "Done from %d with seq = %d", heardFrom, pRouteTable->iSeq);
				outputMsg(buffer);
				continue;
			}
			else
			{
				sprintf(buffer, "Rcv a new route from %d with seq = %d", heardFrom, pRouteTable->iSeq);
				outputMsg(buffer);
			}

			RouteTableDV * tmpRouteTable = (RouteTableDV *) malloc(sizeof(RouteTableDV));
			memcpy(tmpRouteTable,recvBuf + 6, sizeof(RouteTableDV));
			globalNodeInfoDV[heardFrom].pRouteTable = tmpRouteTable;
			 
			if (NULL != oldRouteTable)
			{
				free(oldRouteTable);
			}

			needToRecomputeRoute = 1;

		}

		if (needToRecomputeRoute){
			while (1 != reComputeRouteTableDV())
			{
				usleep(10000);
				sprintf(buffer, "Sleep a little while to reComp");
				outputMsg(buffer);
			}
		}
	}
	sprintf(buffer, "listenForNeighbors() done.");
	outputMsg(buffer);

	//(should never reach here)
	close(globalSocketUDP);
}


//////
void listenForNeighbors()
{
	sprintf(buffer, "listenForNeighbors() has been called.");
	outputMsg(buffer);

	if(usePV())
	{
		
	}
	else
	{
		listenForNeighborsDV();
	}

}

int checkNumberOfLinksDown(int timeOutInSeconds)
{
	sprintf(buffer, "checkNumberOfLinksDown() has been called.");
	outputMsg(buffer);

	int nLinkDown=0;


	struct timeval currentTime;
	gettimeofday(&currentTime, 0);

	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		//skip not connected nodes
		if (i == globalMyID || !globalNodeInfoDV[i].isActive){
			continue;
		}

		int nSecAgo = currentTime.tv_sec - globalLastHeartbeat[i].tv_sec;
		if (nSecAgo < timeOutInSeconds)
		{
			continue;
		}
		fprintf(stderr, "\nPeter: *Link down detected! i = %d : last heard '%d' second(s) ago!", i, nSecAgo);
		globalNodeInfoDV[i].isActive = false;
		nLinkDown++;
	} 

	return nLinkDown;
}


void* monitorLinkDownDV(void* unusedParam)
{
	sprintf(buffer, "monitorLinkDownDV() has been called.");
	outputMsg(buffer);

	while(1)
	{
		int nLinkDown = checkNumberOfLinksDown(2);
		if (!nLinkDown)
		{
			sleep(1);	
		}
		else
		{
			while (0 == reComputeRouteTableDV())
			{
				usleep(10000);
			}
		}
	}
}



// pMy_cost_i_via_j
void findBestRouteToIDV(int i, int* pNext_hop_j, int* pMy_cost_i_via_j)
{
	sprintf(buffer, "findBestRouteToIDV() has been called.");
	outputMsg(buffer);

	int tmpNextHop = -1;
	int tmpCost = -1;

	// looking for the best route for i, and its cost
	for (int j = 0; j < nConnectedNodes; j++)
	{

		int aConnectedNode = connectedNodes[j];

		RouteTableDV* pConnectNode_route_table = globalNodeInfoDV[aConnectedNode].pRouteTable;
		int myCostToConnectedNode= globalNodeInfoDV[aConnectedNode].iCost;

		int connectNode_route_cost = 1000000;
		if (pConnectNode_route_table) {
			connectNode_route_cost = pConnectNode_route_table->iRouteCosts[i];
		}
		else
		{
			continue;
		}

		if (connectNode_route_cost < 0)
		{
			continue;
		}

		//this should not happen but proctect the code anyway
		if (myCostToConnectedNode < 0)
		{
			fprintf(stderr, "***Node %d cost to  %d is -1\n", i, aConnectedNode);
			continue;
		}

		int myCost_to_i_via_connectedNode  = myCostToConnectedNode + connectNode_route_cost;

		if (myCost_to_i_via_connectedNode < 0)
		{
			continue;
		}

		if (tmpCost == -1)
		{
			tmpCost=myCost_to_i_via_connectedNode;
			tmpNextHop=aConnectedNode;
		}
		else if (myCost_to_i_via_connectedNode < tmpCost )
		{
			tmpCost=myCost_to_i_via_connectedNode;
			tmpNextHop=aConnectedNode;
		}
	}

	*pNext_hop_j=tmpNextHop;
	*pMy_cost_i_via_j=tmpCost;

}

void determineConnectedNodesDV ()
{
	sprintf(buffer, "determineConnectedNodesDV() has been called.");
	outputMsg(buffer);

	nConnectedNodes = 0;
	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		if (globalNodeInfoDV[i].isActive) {
			connectedNodes[nConnectedNodes++] = i;
		}
	}
}

// 0 - no updatae due to in the middle of another update;
// 1 - successfully updated;
int reComputeRouteTableDV()
{
	sprintf(buffer, "reComputeRouteTableDV() is called line: %d.", __LINE__);
	outputMsg(buffer);

	if (updatingRouteTable)
	{
		sprintf(buffer, "Warning!!!! reComputeRouteTableDV() is returned at line: %d.", __LINE__);
		outputMsg(buffer);
		return 0;
	}

	// start updating route table
	int updatingRouteTable = 1;

	determineConnectedNodesDV();

	// iterate over globalNodeInfo[]
	for (int i = 0; i < MAX_NODE_SIZE; i++) {

		if (i == globalMyID){
			continue;
		}

		NodeInfoDV *pNodeInfo = &globalNodeInfoDV[i];

		int my_cost_i_via_j;
		int next_hop_j = -1;

		// Store the old values
		int old_next_hop_last = pNodeInfo->iDest;
		int old_my_route_cost_to_i = globalLocalRouteTable.iRouteCosts[i];
			
		findBestRouteToIDV(i, &next_hop_j, &my_cost_i_via_j);

		// case 1: no route to i found
		if (-1 == next_hop_j)
		{
			pNodeInfo->iDest = -1;
			globalLocalRouteTable.iRouteCosts[i] = -1;

			// value changes detection
			if (old_next_hop_last != pNodeInfo->iDest || 
				old_my_route_cost_to_i != globalLocalRouteTable.iRouteCosts[i] ) 
			{
				routeTableNeedUpdate = 1;
			}
			continue;
		}

		// If route to i is found
		// assign the next hop
		pNodeInfo->iDest = next_hop_j;
		int my_cost_to_j = globalNodeInfoDV[next_hop_j].iCost;
		if (my_cost_to_j == -1){
			sprintf(buffer, "nexthop(%d) to %d is -1!!!", next_hop_j, i);
			outputMsg(buffer);
			continue;
		}
	
		// assign the my cost to i
		globalLocalRouteTable.iRouteCosts[i] = my_cost_i_via_j;

		// value changes detection
		if (old_next_hop_last != pNodeInfo->iDest || 
			old_my_route_cost_to_i != globalLocalRouteTable.iRouteCosts[i] ){
			routeTableNeedUpdate = 1;
		}
	}

	if (routeTableNeedUpdate)
	{
		globalLocalRouteTable.iSeq++;
		sprintf(buffer, "RouteTableDV %d updated!", globalMyID);
		outputMsg(buffer);
		outputNodeInfo();
	}

	// end updating route table
	updatingRouteTable = 0;
	return 1;
}

void sendMsg(int destID, const char* buf, int length)
{
	sprintf(buffer, "sendMsg() is called line: %d.", __LINE__);
	outputMsg(buffer);

	sendto(globalSocketUDP, buf, length, 0, (struct sockaddr*) &globalNodeAddrs[destID], sizeof(globalNodeAddrs[destID]));
	return;
}

void forwardMessage(unsigned short destID, unsigned char * recvBuf,int nBytes)
{
	sprintf(buffer, "forwardMessage() is called line: %d.", __LINE__);
	outputMsg(buffer);

	//sprintf(buffer, "forwardMessage() is called.");
	//outputMsg(buffer);
	char* message =(char*)(recvBuf + 6);
	int nextHop = globalNodeInfoDV[destID].iDest;
	if (-1 == nextHop)
	{
		logUnreachable(destID);
		return;
	}

	logForward(message, destID, nextHop);

	sendMsg(nextHop, recvBuf, nBytes);
}

void sendMessage(int destID, unsigned char * recvBuf,int nBytes)
{
	sprintf(buffer, "sendMessage() is called line: %d.", __LINE__);
	outputMsg(buffer);

	int nextHop = globalNodeInfoDV[destID].iDest;
	char* message = (char*)&recvBuf[6];
	logSend(message, destID, nextHop);
	fprintf(stderr, "Need to send msg to %d via %d\n", destID, nextHop);
	if (-1 == nextHop)
	{
		fprintf(stderr, "Ignore to send.");
		logUnreachable(destID);
		return;
	}
	sendMsg(nextHop, recvBuf, nBytes);
}

char logLine[1000];

void logMsg(char *pStr) {
	fwrite(logLine, 1, strlen(logLine), runingLogFile);
	fflush(runingLogFile);
	fprintf(stderr, logLine);
}

void logSend(const char* message, int dest, int nexthop)
{
	sprintf(logLine, "sending packet dest %d nexthop %d message %s\n", dest, nexthop, message);
	logMsg(logLine);
}

void logReceive(const char* message)
{
	sprintf(logLine, "receive packet message %s\n", message);
	logMsg(logLine);
}

void logForward(const char* message, int dest, int nexthop)
{
	sprintf(logLine, "forward packet dest %d nexthop %d message %s\n", dest, nexthop, message);
	logMsg(logLine);
}

void logUnreachable(int dest)
{
	sprintf(logLine, "unreachable dest %d\n", dest);
	logMsg(logLine);
}

void outputNodeInfo()
{
	NodeInfoDV *pNode;
	sprintf(buffer, "outputNodeInfo() is called line: %d.", __LINE__);
	outputMsg(buffer);

	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		pNode = globalNodeInfoDV + i; 
		if ((pNode->iCost == 1) && (-1 == pNode->iDest) && (-1 == globalLocalRouteTable.iRouteCosts[i]) && (!pNode->isActive))
		{
			continue;
		}
		sprintf(buffer, "%i: cost = %i, iDest = %i, iRouteCost = %i, isActive = %i", i,
			pNode->iCost, pNode->iDest, globalLocalRouteTable.iRouteCosts[i], pNode->isActive);
		outputMsg(buffer);
	}
	sprintf(buffer, "****** done node info**********.");
	outputMsg(buffer);

}


void initNodes()
{
	sprintf(buffer, "initNodes() has been called.");
	outputMsg(buffer);

	if(usePV() == 1)
	{
		//initNodesPV();
	}
	else
	{
		initNodesDV();
		outputNodeInfo();
	}
}

void initRouteCosts()
{
	sprintf(buffer, "initRouteCosts() has been called.");
	outputMsg(buffer);

	if(usePV() == 1)
	{
		//initCostsPV();
	}
	else
	{
		initCostsDV();
	}
}


///////// general


void* monitorLinkDown(void* unusedParam)
{
	sprintf(buffer, "monitorLinkDown() has been called.");
	outputMsg(buffer);

	if(usePV())
	{
		
	}
	else
	{
		monitorLinkDownDV(unusedParam);
	}
}

