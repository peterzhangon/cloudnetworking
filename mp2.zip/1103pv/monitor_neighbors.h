#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <sys/time.h>
#include <signal.h>
#include <unistd.h>
#include <stdbool.h> 

// Mutex
// https://www.thegeekstuff.com/2012/05/c-mutex-examples/
/*
pthread_t tid[2];
int counter;
pthread_mutex_t lock;
*/

// ********* orig begin *************
#define MAX_NODE_SIZE 256
#define MAX_PATH_NUM 200
#define MAX_PATH_SIZE 20

void listenForNeighbors();
void* announceToNeighbors(void* unusedParam);


int globalMyID = 0;

//last time you heard from each node. TODO: you will want to monitor this
//in order to realize when a neighbor has gotten cut off from you.
struct timeval globalLastHeartbeat[MAX_NODE_SIZE];

//our all-purpose UDP socket, to be bound to 10.1.1.globalMyID, port 7777
int globalSocketUDP;
//pre-filled for sending to 10.1.1.0 - 255, port 7777
struct sockaddr_in globalNodeAddrs[MAX_NODE_SIZE];
// ********* orig end *************

// ********* peter new functions begin *************
char buffer[2000];
char peterDebugBuffer[3000];
FILE *peterLogFile = NULL;
char logFileName[200];

// Debug print
unsigned int  gDbgRoute = 1;
unsigned int  gDbgStop = 2;
unsigned int  gDbgMsg = 4;
unsigned int  gDbgHeartBeat = 8;

unsigned int  gDbg = 5;

int gTestCaseId = 0;

void outputAllNodeInfo();
void outputAnArray(int *path, int len);

int printDbg(int iDest)
{
	if(iDest == 77)
	{
		return 1;
	}
	return 0;
}

////////////////////////////////
int reComputeRouteTableDV();
void determineConnectedNodesDV ();
void findBestRouteToIDV(int i, int* pNext_hop_j, int* pMy_cost_i_via_j);
int checkNumberOfLinksDownDV(int timeOutInSeconds);
void* announceToNeighborsDV(void* unusedParam);
void* monitorLinkDownDV(void* unusedParam);
void initNodesDV();
void prepare(char** argv);
void initCostsDV();
void outputNodeInfoDV();
void listenForNeighborsDV();
void sendMessageDV(int destID, unsigned char * recvBuf,int nBytes);
void forwardMessageDV(unsigned short destID, unsigned char * recvBuf,int nBytes);
void broadcastRouteTableDV();
void outputRouteTableDV(RouteTableDV  * pRoutingTable,  int isSent);

///////////////////////////////
void sendMsg(int iDest, const char* buf, int length);

void debug_stop() {
	if (gDbg & gDbgStop) {
		return;
	}
	//fprintf(stderr, "\n**************** Begin to debug_stop *************");
	char * tmpFile = (char *)malloc(100);
	char * pid = (char *)malloc(100);

	sprintf(pid, "%d", getpid());
	// ********************* change to your own directory *****************
	sprintf(tmpFile, "/home/ec2-user/mp2/code/pid/pid_%s", pid);

	FILE *fp = fopen (tmpFile, "w+");
	fclose(fp);

	fprintf(stderr, "*** debug file = %s", tmpFile);
	int cnt = 0;
	fprintf(stderr, "\nPleasae remove the file %s to continue.", tmpFile);

	while (1) {
		if(access(tmpFile, F_OK) != 0)
		{
			fprintf(stderr, "\n%s does not exist, so continue the thread.", tmpFile);
			break;
		} else if (cnt >= 5000) {
			fprintf(stderr, "\n%s to be removed, so the current thread is blocked here.", tmpFile);
			cnt = 0;
		}
		cnt++;
		sleep(1);
		break;
	}

	fprintf(stderr, "\n**************** Begin to process the data via pid");
	free(tmpFile);
	free(pid);

}

int cntFlush = 0;
void outputMsg(char * str)
{
	if ((gDbg & gDbgMsg) == 0)
	{
		return;
	}
	if(globalMyID > 3 || gTestCaseId != 5)
	{
		//return;
	}

	cntFlush++;
	//fprintf(stderr, "\n%d: %s", globalMyID, str);

	//fprintf(stderr, "\nstr: %s, File: %s, Line: %d", str,  __FILE__, __LINE__);
	time_t current_time;
	struct tm * time_info;
	char tmpTime[100];
	//fprintf(stderr, "\nFile: %s, Line: %d", __FILE__, __LINE__);

	time(&current_time);
	time_info = localtime(&current_time);

	strftime(tmpTime, 26, "%M:%S", time_info);

	// sprintf(peterDebugBuffer, "\n%ld_%s:%s", (long)getpid(), tmpTime, str);
	sprintf(peterDebugBuffer, "\n%s:%s", tmpTime, str);
	fwrite(peterDebugBuffer, 1, strlen(peterDebugBuffer), peterLogFile);
	if (cntFlush >= 100)
	{
		fflush(peterLogFile);
		cntFlush = 0;
	}
}

void prepareLogFile()
{
	//fprintf(stderr, "\nprepareLogFile() File: %s, Line: %d", __FILE__, __LINE__);

	time_t seconds;
	//fprintf(stderr, "\nFile: %s, Line: %d", __FILE__, __LINE__);

	seconds = time(NULL);
	sprintf(logFileName, "./log/%ld_%d", seconds, globalMyID);
	//fprintf(stderr, "\nPeter's debug log file = %s", logFileName);
	peterLogFile = fopen(logFileName, "w");
	if (NULL == peterLogFile) {
		fprintf(stderr, "\nFailed to create the log file = %s", logFileName);
	} else {
		//fprintf(stderr, "\nSucceded to create the log file = %s", logFileName);
	}
	strcpy(peterDebugBuffer, "\nBegin the test.");
	fwrite(peterDebugBuffer, 1, strlen(peterDebugBuffer), peterLogFile);
	fflush(peterLogFile);
	
	sprintf(buffer, "My node id: [%d]", globalMyID);
	outputMsg(buffer);
}


FILE *runingLogFile;
void setupruningLogFile(const char* fileName)
{
	sprintf(buffer, "Created the log file for the app.");
	outputMsg(buffer);

	runingLogFile = fopen(fileName, "w+"); 
}

// Each dest has its own global seq
// When the following cases happen, we need ++:
// Case 1: When it is up or down;
// Case 2: When its cost to neibour is changed;
// ????
int globalSequence = 0;
int globalHeartBeatSequence = 0;

// Per path to a specific dest
typedef struct PathInfo {
	int  iCost;
	int  iRouteSequence;
	int  iPathLen;
	// The first one should be the next hop
	int  iPath[MAX_PATH_SIZE];
} PathInfo;


typedef struct RouteTableDV {
	int iSeq;
	int iRouteCosts[MAX_NODE_SIZE];
} RouteTableDV;

typedef struct NodeInfoDV {
	int  iCost;
	int  iDest;
	bool isActive;
	RouteTableDV *pRouteTable;
} NodeInfoDV;


typedef struct NodeInfo {
	int  iCost;
	int  isActive;
	int  iNextHop;
	int  iNodeId;
	int  iRouteSequence;
	int  iheartBeatSequence;
	int  iDest;

	// To store the best path based on the cost
	int  iBestIdx;
	// To a specific dest, from this current host to that dest, we may have multiple path	
	PathInfo*  iPaths[MAX_NODE_SIZE];
	
	RouteTable *pRouteTable; // DV
} NodeInfo;


// Here we have 256 at most
// The cost here is all the cost of the path
NodeInfo globalNodeInfo[MAX_NODE_SIZE];
// This is the practical cost between this node to each dest
int globalCosts[MAX_NODE_SIZE];


// DV
/*
int routeTableNeedUpdate = 1;
int updatingRouteTable = 0;
RouteTable globalLocalRouteTable;
int nConnectedNodes = 0;
int connectedNodes[MAX_NODE_SIZE];
char buffer[2000];
char peterDebugBuffer[3000];
void determineConnectedNodes ();
void findBestRouteToI(int i, int* pNext_hop_j, int* pMy_cost_i_via_j);
int reComputeRouteTable();
void forwardMessage(unsigned short destID, unsigned char * recvBuf,int bytesRecvd);
void sendMessage(int destID, unsigned char * recvBuf,int nBytes);
*/
void initNodePaths(int i) 
{
	globalNodeInfo[i].iBestIdx = -1;
	// Init all the paths
	// We do not have so many paths, have such a big number just in case
	for (int j = 0; j < MAX_NODE_SIZE; j++)
	{
		// At the begining, we do not have any path yet
		globalNodeInfo[i].iPaths[j] = NULL;
	}
}

// case 5
int gLinksToBeMonitoredCase_5_Src[] = {11, 1};//,2,3,4,6};
int gLinksToBeMonitoredCase_5_Dest[] = {66, 2};//,3,4,5,7};
//int gLinksToBeMonitoredCase_5_AllNodes[] = {11, 66};//, 1, 2, 3, 4, 5,6,7};
int gLinksToBeMonitoredCase_5_Size = 2;

// case 8
int gLinksToBeMonitoredCase_8_Src[] =  {4,  11, 60, 3, 13, 23, 33, 43, 53, 63, 73, 70};
int gLinksToBeMonitoredCase_8_Dest[] = {42, 22, 70, 4, 14, 24, 34, 44, 54, 64, 74, 71};
//int gLinksToBeMonitoredCase_8_AllNodes[] = {60, 3, 13, 23, 33, 43, 53, 63, 73, 70, 4, 14, 24, 34, 44, 54, 64, 74};
int gLinksToBeMonitoredCase_8_Size = 12;


// case 6 / 7
int gLinksToBeMonitoredCase_6_Src[] = {6, 1, 2};
int gLinksToBeMonitoredCase_6_Dest[] = {7, 4, 3};
//int gLinksToBeMonitoredCase_6_AllNodes[] = {1, 2, 3, 4, 6, 7};
int gLinksToBeMonitoredCase_6_Size = 3;

int* gLinksSrc = NULL;
int* gLinksDest = NULL;
int  gLinksSize = 0;
int  gLinksNodeSize = 0;

int gLinksNeibours[10];
int gLinksNeiboursSize = 0;

//int* globalNeibours[MAX_NODE_SIZE];

// 1
int globalNodes_1[3][5] = {{1, 2, -1, -1, -1}, // 56 rows (8 * 7)
						   {2, 3, -1, -1, -1},
						   {3, 2, -1, -1, -1}};

// 2 6 7
int globalNodes_267[9][5] = {{0, 255, -1, -1, -1}, // 56 rows (8 * 7)
						   {255, 1, -1, -1, -1},
						   {1, 2, 4, 5, 6},
						   {2, 1, 5, -1, 3},
						   {3, 2, 4, -1, -1},
						   {4, 1, 3, 7, -1},
						   {5, 1, 6, 2, -1},
						   {6, 1, 5, 7, -1},
						   {7, 4, 6, -1, -1}};

// 3 and 4, and 5
// At last, each node should be able clearly know its neibours.
int globalNodes_3458[64][5] = 
						  {{0,-1,  1, -1, 10}, // 64 rows (8 * 8)
						   {1, 0,  2, -1, 11},
						   {2, 1,  3, -1, 12},  // line 1
						   {3, 2,  4, -1, 13},
						   {4, 3,  5, -1, 14},
						   {5, 4,  6, -1, 15},
						   {6, 5,  7, -1, 16},
						   {7, -1, -1, -1,17},
						   //////////////////////
						   {10, -1, 11, 0, 20},
						   {11, 10, 12, 1, 21},
						   {12, 11, 13, 2, 22}, // line 2
						   {13, 12, 14, 3, 23},
						   {14, 13, 15, 4, 24},
						   {15, 14, 16, 5, 25},
						   {16, 15, 17, 6, 26},
						   {17, 16, -1, 7, 27},
						   //////////////////////
						   {20, -1, 21, 10, 30},
						   {21, 20, 22, 11, 31},
						   {22, 21, 23, 12, 32}, // line 3
						   {23, 22, 24, 13, 33},
						   {24, 23, 25, 14, 34},
						   {25, 24, 26, 15, 35},
						   {26, 25, 27, 16, 36},
						   {27, 26, -1, 17, 37},
						   //////////////////////
						   {30, -1, 31, 20, 40},
						   {31, 30, 32, 21, 41},
						   {32, 31, 33, 22, 42},
						   {33, 32, 34, 23, 43},// line 4
						   {34, 33, 35, 24, 44},
						   {35, 34, 36, 25, 45},
						   {36, 35, 37, 26, 46},
						   {37, 36, -1, 27, 47},
						   //////////////////////
						   {40, -1, 41, 30, 50},
						   {41, 40, 42, 31, 51},
						   {42, 41, 43, 32, 52},// line 5
						   {43, 42, 44, 33, 53},
						   {44, 43, 45, 34, 54},
						   {45, 44, 46, 35, 55},
						   {46, 45, 47, 36, 56},
						   {47, 46, -1, 37, 57},
						   //////////////////////
						   {50, -1, 51, 40, 60},
						   {51, 50, 42, 41, 61},
						   {52, 51, 43, 42, 62},
						   {53, 52, 44, 43, 63},// line 6
						   {54, 53, 45, 44, 64},
						   {55, 54, 46, 45, 65},
						   {56, 55, 47, 46, 66},
						   {57, 56, -1, 47, 67},
						   //////////////////////
						   {60, -1, 61, 50, 60},
						   {61, 60, 62, 51, 71},
						   {62, 61, 63, 52, 72},// line 7
						   {63, 62, 64, 53, 73},
						   {64, 63, 65, 54, 74},
						   {65, 64, 66, 55, 75},
						   {66, 65, 67, 56, 76},
						   {67, 66, -1, 57, 77},
							//////////////////////
						   {70, -1, 71, 60, -1},
						   {71, 70, 72, 61, -1},
						   {72, 71, 73, 62, -1},// line 8
						   {73, 72, 74, 63, -1},
						   {74, 73, 75, 64, -1},
						   {75, 74, 76, 65, -1},
						   {76, 75, 77, 66, -1},
						   {77, 76, -1, 67, -1}

							};


int globalForwardNeibours[MAX_NODE_SIZE];
int globalForwardNeiboursCnt = 0;


// To save time to send msgs to non-existing node
int globalNeibours[MAX_NODE_SIZE];
int globalNeiboursCnt = 0;

int getV(int *ptr, int i, int j)
{
	return *(ptr + i * 5 + j);

}
// To send pkgs to the really connected nodes.
void initForwardNeibours()
{
	int row = 0;
	int col = 5;

	int *ptr = NULL;
	
	sprintf(buffer, "********* Begin to output my Myid_%d has the neibours at line: %d.", globalMyID,  __LINE__);
	outputMsg(buffer);

	if((1 == gTestCaseId))
	{
		row = 3;
		ptr = &globalNodes_1[0][0];
		// do not want to bother
		//return;
 	}
	else if((2 == gTestCaseId) || (6 == gTestCaseId) || (7 == gTestCaseId))
	{
		row = 9;
		ptr = &globalNodes_267[0][0];
	}
	else if((3 == gTestCaseId) || (4 == gTestCaseId) || (5 == gTestCaseId) || (8 == gTestCaseId))
	{
		row = 64;
		ptr = &globalNodes_3458[0][0];
	}
	else
	{
		fprintf(stderr, "wrong test case id.");
		sprintf(buffer, "initNodeInfo() is called.");
		outputMsg(buffer);
		exit(1);
	}

	for (int i = 0; i < row; i++)
	{
		if(getV(ptr, i, 0) != globalMyID)
		{
			continue;
		}

		int cnt = 0;
		for(int j = 1; j < 5; j++)
		{
			if(getV(ptr, i, j) < 0)
			{
				continue;
			} 
			globalForwardNeibours[cnt++] = getV(ptr, i, j);
		}

		if(cnt <= 0)
		{
			fprintf(stderr, "wrong test case id.");
			sprintf(buffer, "initNodeInfo() is called.");
			outputMsg(buffer);
			exit(1);
		}

		fprintf(stderr, "Myid_%d ********** has the %d neibours at line: %d.", globalMyID, cnt, __LINE__);
		sprintf(buffer, "Done done to output Myid_%d has the %d neibours at line: %d.", globalMyID, cnt, __LINE__);
		outputMsg(buffer);
		int *pTmp = globalForwardNeibours;
		outputAnArray(pTmp, cnt);
		globalForwardNeiboursCnt = cnt;

		return;
	}

}

void initNodeInfoDV()
{
	sprintf(buffer, "initNodeInfo() is called.");
	outputMsg(buffer);

	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		globalNodeInfo[i].iCost = 1;
		globalNodeInfo[i].iDest = -1;
		globalNodeInfo[i].isActive = 0;
		globalNodeInfo[i].pRouteTable = NULL;
	}
	globalNodeInfo[globalMyID].iCost = 0;
	globalNodeInfo[globalMyID].iDest = globalMyID;
	globalNodeInfo[globalMyID].isActive = 1;
}

void initNodes()
{
	sprintf(buffer, "initNodeInfo() is called.");
	outputMsg(buffer);

	// From this host to any following dest
	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		globalNodeInfo[i].isActive = 0;
		globalNodeInfo[i].iCost = 9999;
		globalNodeInfo[i].iNextHop = -1;
		globalNodeInfo[i].iNodeId = i;
		globalNodeInfo[i].iRouteSequence = -1;
		globalNodeInfo[i].iheartBeatSequence = 0;
		globalNodeInfo[i].iDest = i;
		globalNodeInfo[i].pRouteTable = NULL; // DV
		for (int j = 0; j < MAX_NODE_SIZE; j++ )
		{
			initNodePaths(i);
		}
	}
	globalNodeInfo[globalMyID].iCost = 0;
	globalNodeInfo[globalMyID].isActive = 1;
	globalNodeInfo[globalMyID].iBestIdx = -1;
	globalNodeInfo[globalMyID].iRouteSequence = -1;
	globalNodeInfo[globalMyID].iheartBeatSequence = -1;

	if((5 == gTestCaseId))
	{
		initNodeInfoDV();
	}
}

void initRouteCostsDV()
{
	sprintf(buffer, "initRouteCosts() is called.");
	outputMsg(buffer);

	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		globalLocalRouteTable.iRouteCosts[i] = -1;
	}
	globalLocalRouteTable.iRouteCosts[globalMyID] = 0;
}

void initCosts()
{
	sprintf(buffer, "initCosts() is called.");
	outputMsg(buffer);

	// From this host to any following dest
	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		globalCosts[i] = 1;
	}
	globalCosts[globalMyID] = 0;

	if((5 == gTestCaseId))
	{
		initRouteCostsDV();
	}
}


void readOneLineCost(char* line, int* pNode, int* pCost)
{
	int init_size = strlen(line);
	char *p = line;
	char delim[] = " \n";
	char *ptr1 = strtok(line, delim);
	char *ptr2 = strtok(NULL, delim);
	*pNode = atoi(ptr1);
	*pCost = atoi(ptr2);
}

char globalTopology[100];
char topology[] = "nodes.txt";


char case5[] = "test5/";
char case8[] = "test8/";
char testCaseId[3];
void processInitCostFile(const char* fileName)
{
	FILE* fp;
	char* line;
	size_t len = 0;
	ssize_t read;
	int nodeId, cost;

	for(int i = 0; i < strlen(fileName); i++)
	{
		globalTopology[i] = fileName[i];
		if(fileName[i] == '/')
		{
			globalTopology[i + 1] = '\0';
			testCaseId[0] = globalTopology[i - 1];
			testCaseId[1] = '\0';
			gTestCaseId = atoi(testCaseId);
			
			//fprintf(stderr, "File *********globalTopology is: %s. gTestCaseId: %d\n", globalTopology, gTestCaseId);
			sprintf(buffer, "File *********globalTopology is: %s. gTestCaseId: %d", globalTopology, gTestCaseId);
			outputMsg(buffer);

			strcat(globalTopology, topology);
			break;
		}
	}
	// initForwardNeiboursNew();
	initForwardNeibours();

	if((5 == gTestCaseId) || (8 == gTestCaseId))
	{
		gLinksSrc = gLinksToBeMonitoredCase_5_Src;
		gLinksDest = gLinksToBeMonitoredCase_5_Dest;
		//gLinksAllNodes = gLinksToBeMonitoredCase_5_AllNodes;
		gLinksSize = gLinksToBeMonitoredCase_5_Size;
	}

	if((6 == gTestCaseId) || 7 == gTestCaseId)
	{
		gLinksSrc = gLinksToBeMonitoredCase_6_Src;
		gLinksDest = gLinksToBeMonitoredCase_6_Dest;
		//gLinksAllNodes = gLinksToBeMonitoredCase_6_AllNodes;
		gLinksSize = gLinksToBeMonitoredCase_6_Size;
	}

	if(NULL != gLinksSrc)
	{
		int cnt = 0;
		for(int i = 0; i < gLinksSize; i++)
		{
			if(gLinksDest[i] == globalMyID)
			{
				gLinksNeibours[cnt++] = gLinksSrc[i];
			}
			if(gLinksSrc[i] == globalMyID)
			{
				gLinksNeibours[cnt++] = gLinksDest[i];
			}
		}
		gLinksNeiboursSize = cnt;
	}
	// Output to double confirm
	sprintf(buffer, "*** Begin to print the links info %d:", gTestCaseId, __LINE__);
	outputMsg(buffer);
	outputAnArray(gLinksSrc, gLinksSize);
	outputAnArray(gLinksDest, gLinksSize);
	sprintf(buffer, "All the nodes for %d:", gTestCaseId);
	outputMsg(buffer);
	outputAnArray(gLinksNeibours, gLinksNeiboursSize);
	sprintf(buffer, "*** end to print the links info %d:", gTestCaseId, __LINE__);
	

	fprintf(stderr, "\n\nStart test case %d on node %d at line %d\n", gTestCaseId, globalMyID, __LINE__);

	fp = fopen(fileName, "r");
	sprintf(buffer, "Begin to parse cost file: %s", fileName);
	outputMsg(buffer);

	if (fp == NULL)
	{
		sprintf(buffer, "Unable to open the cost file: %s.", fileName);
		outputMsg(buffer);

		exit(1);
	}

	while ((read = getline(&line, &len, fp)) != -1)
	{
		sprintf(buffer, "Got a line: %s", line);
		outputMsg(buffer);
		readOneLineCost(line, &nodeId, &cost);
		sprintf(buffer, "cost to dest_%d, %d -> %d", nodeId, globalCosts[nodeId], cost);
		outputMsg(buffer);
		globalCosts[nodeId] = cost;
	}

	if (line){
		free(line);
	}
	fclose(fp);

	sprintf(buffer, "Done done to parse cost file: %s", fileName);
	outputMsg(buffer);
}


// read neibour info from nodes.txt to get rid off uselss transmission. This one was replaced by a 2 dimension array already.
void processNeibours()
{
	FILE* fp;
	char* line;
	size_t len = 0;
	ssize_t read;
	int node1, node2;

	fp = fopen(globalTopology, "r");
	sprintf(buffer, "****File location: %s.", globalTopology);
	outputMsg(buffer);

	if (fp == NULL)
	{
		sprintf(buffer, "Unable to open the topology file: %s.", globalTopology);
		outputMsg(buffer);

		exit(1);
	}
	sprintf(buffer, "begin to read & parse the file: %s.", globalTopology);
	outputMsg(buffer);

	read = getline(&line, &len, fp);
	sprintf(buffer, "len: %s", line);
	outputMsg(buffer);

	char tmp[10];
	int cnt = 0;
	for(int i = 0; i < strlen(line); i++)
	{
		tmp[cnt++] = line[i];
		if(line[i] == ' ' || line[i] == '\n')
		{
			tmp[cnt] = '\0';
			globalNeibours[globalNeiboursCnt++] = atoi(tmp);
			cnt = 0;
		}
	}

	fclose(fp);

	sprintf(buffer, "Done done to parse topology file to get all the nodes: %s", globalTopology);
	outputMsg(buffer);
	outputAnArray(globalNeibours, globalNeiboursCnt);
}


void cancelRouteTable(int iDest);

int checkNumberOfLinksDown(int timeOutInSeconds){

	if((5 != gTestCaseId) && (6 != gTestCaseId) && (7 != gTestCaseId) && (8 != gTestCaseId))
	{
		return 0;
	}

	int nLinkDown=0;

	struct timeval currentTime;
	gettimeofday(&currentTime, 0);

	for (int i = 0; i < gLinksNeiboursSize; i++)
	{
		int iDest = gLinksNeibours[i];
		sprintf(buffer, "Myid_%d: dest_%d total: %d Line:%d\n\n\n", globalMyID, iDest, gLinksNeiboursSize, __LINE__);
		outputMsg(buffer);

		//skip if it knows to be down already
		if (1 != globalNodeInfo[iDest].isActive)
		{
			continue;
		}
		sprintf(buffer, "Myid_%d: dest_%d total: %d Line:%d\n\n\n", globalMyID, iDest, gLinksNeiboursSize, __LINE__);
		outputMsg(buffer);

		int msAgo = currentTime.tv_sec * 1000 + currentTime.tv_usec /1000  - 
					globalLastHeartbeat[iDest ].tv_sec * 1000 + globalLastHeartbeat[iDest].tv_usec /1000;
			
		if (msAgo < timeOutInSeconds * 1000)
		{
			continue;
		}

		fprintf(stderr, "Myid_%d: dest_%d **** remove ****** is down: last heard '%d' msecond(s) ago!\n\n\n", globalMyID, iDest, msAgo);
		globalNodeInfo[iDest].isActive = 0;
		sprintf(buffer, "Myid_%d: dest_%d ***** remove *****  is down: last heard '%d' msecond(s) ago!\n\n\n", globalMyID, iDest, msAgo);
		outputMsg(buffer);
		cancelRouteTable(iDest);

		nLinkDown++;
	} 
	return nLinkDown;
}

void* monitorLinkDown(void* unusedParam)
{
	while(1)
	{
		int nLinkDown = checkNumberOfLinksDown(3);
		if (!nLinkDown)
		{
			usleep(1000*1000);//1000ms	
		}

		if ((5 == gTestCaseId) && (8 == gTestCaseId))
		{
			while (0 == reComputeRouteTable())
			{
				usleep(10000);
			}
		}

	}
}

// ********* peter new functions end *************


// For all the dest nodes
typedef struct PathRoute {
	int iCost;
	int iPathLen;
	int iRouteSequence;
	int iHearBeatSequence;
	int msgType;
	// The first one should be the next hop
	int iPath[MAX_PATH_SIZE];
} PathRoute;

// For all the dest nodes
typedef struct HeartBeat {
	int iHeartBeatSeq;
	int iDest;
} HeartBeat;

PathRoute globalHeartBeat; 

char pathRouteBuffer[MAX_NODE_SIZE * 6 + 4];
char tmpPathRouteBuffer[500];
char tmpPathRouteBufferPrefix[500];
void updateCancel(PathRoute* pPathRoute);

void outputPathRoute(PathRoute* pPthRoute, int isSend) 
{
	pathRouteBuffer[0] = '\0';
	//sprintf(buffer, "+++++++Route++++++++");
	//outputMsg(buffer);

	sprintf(buffer, "Line: %d, isSend: %d, outputP: path route: dest_%d, cost: %d, pathLen: %d, iRoutingSeq: %d, msgType: %d.", 
		__LINE__, isSend, pPthRoute->iPath[0], pPthRoute->iCost, pPthRoute->iPathLen, pPthRoute->iRouteSequence, pPthRoute->msgType);
	outputMsg(buffer);

	for (int i = 0; i < pPthRoute->iPathLen; i++)
	{
		sprintf(tmpPathRouteBuffer, "%d, ", pPthRoute->iPath[i]);
		strcat(pathRouteBuffer, tmpPathRouteBuffer);
	}
	sprintf(buffer, "outputP: msgType: %d, path for dest_%d : %s.", pPthRoute->msgType, pPthRoute->iPath[0], pathRouteBuffer);
	outputMsg(buffer);

	//sprintf(buffer, "--");
	//outputMsg(buffer);
}


void outputAnArray(int *path, int len)
{
	tmpPathRouteBuffer[0] = '\0';
	pathRouteBuffer[0] = '\0';
	for (int i = 0; i < len; i++)
	{
		sprintf(tmpPathRouteBuffer, "%d, ", path[i]);
		strcat(pathRouteBuffer, tmpPathRouteBuffer);
	}
	sprintf(buffer, "outputAnArray: %s Line: %d.", pathRouteBuffer, __LINE__);
	outputMsg(buffer);
}

void outputNodeInfo(NodeInfo* pNodeInfo) 
{
	pathRouteBuffer[0] = '\0';
	//sprintf(buffer, "outputN: +++++++++ Node +++++++++");
	//outputMsg(buffer);
	int bestIdx = pNodeInfo->iBestIdx;
	if(bestIdx < 0)
	{
		//sprintf(buffer, "outputN: No any path yet for dest_%d", pNodeInfo->iDest);
		//outputMsg(buffer);
		return;
	}

	
	// Per path
	int isBest;
	int len;
	int* path;
	int cost;
	int seq;
	// Per path
	for(int j = 0; j < MAX_PATH_NUM; j++)
	{
		if (pNodeInfo->iPaths[j] == NULL)
		{
			continue;
		}
		if(j == bestIdx)
		{
			isBest = 1;
		}
		else
		{
			isBest = 0;
		}
		len = pNodeInfo->iPaths[j]->iPathLen;
		path = pNodeInfo->iPaths[j]->iPath;
		sprintf(tmpPathRouteBufferPrefix, " line: %d outputNodeInfo: dest_%d, isBest:%d, idx: %d, cost: %d, pathLen: %d, seq: %d,",
			__LINE__,
			pNodeInfo->iDest,
			isBest, j, pNodeInfo->iPaths[j]->iCost,
			len, pNodeInfo->iPaths[j]->iRouteSequence);
		// the detailed path
		tmpPathRouteBuffer[0] = '\0';
		pathRouteBuffer[0] = '\0';
		for (int i = 0; i < len; i++)
		{
			sprintf(tmpPathRouteBuffer, "%d, ", path[i]);
			strcat(pathRouteBuffer, tmpPathRouteBuffer);
		}
		sprintf(buffer, "outputN: %s path:  %s.", tmpPathRouteBufferPrefix, pathRouteBuffer);
		outputMsg(buffer);
	}

	//sprintf(buffer, "outputN: --");
	//outputMsg(buffer);
}

void outputAllNodeInfo() 
{
	pathRouteBuffer[0] = '\0';
	sprintf(buffer, "+++++++++ Begin outputAllNodeInfo() +++++++++");
	outputMsg(buffer);
	outputAnArray(globalNeibours, globalNeiboursCnt);
	for(int i = 0; i < globalNeiboursCnt; i++)
	{
		int iDest = globalNeibours[i];
		if(printDbg(iDest))
		{
			sprintf(buffer, "********* remove Before to print the dest_%d Line: %d.", iDest, __LINE__);
			outputMsg(buffer);
		}
		outputNodeInfo(&globalNodeInfo[iDest]);
		if(printDbg(iDest))
		{
			sprintf(buffer, "********* remove after to print the dest_%d Line: %d.", iDest, __LINE__);
			outputMsg(buffer);
		}
	}
	//sprintf(buffer, "+++++++++ End outputAllNodeInfo() +++++++++");
	//outputMsg(buffer);
}

// ********* orig function *************
//Yes, this is terrible. It's also terrible that, in Linux, a socket
//can't receive broadcast packets unless it's bound to INADDR_ANY,
//which we can't do in this assignment.
// ------------------------------------
// Broadcase that node's info. And its neibour((direct or in-direct)) will process and forward it
int filterSendCnt = 0;
void sendLinkCheckMsg(PathRoute *pTmpPathRoute, int* node1, int *node2)
{
	char sendBuf[6 + sizeof(PathRoute)];
	filterSendCnt++;

	// For example, node 11 -> nnode 66 for case 5
	for (int j = 0; j < gLinksSize; j++) 
	{
		if(globalMyID != node1[j])
		{
			continue;
		}
		//fprintf(stderr, "LinkInfo: ssendMsgToDetectThePhysicalLink at line: %d.\n", __LINE__);
		// 1. message label: 'routes'
		strcpy(sendBuf, "routes");
		pTmpPathRoute->iPathLen = 2;
		pTmpPathRoute->iPath[0] = node1[j];
		pTmpPathRoute->iPath[1] = node2[j];
		pTmpPathRoute->iCost = 0;
		pTmpPathRoute->msgType = 321;

		pTmpPathRoute->iRouteSequence = globalSequence++;
		pTmpPathRoute->iHearBeatSequence = globalHeartBeatSequence++;

		//if(filterSendCnt == 10)
		{
			filterSendCnt = 0;
			//rintf(stderr, "LinkInfo: my id: %d, send msgs to detect the physically link between (%d, %d) at line: %d.\n", globalMyID, node1[j],  node2[j], __LINE__);
		}
		sprintf(buffer, "LinkInfo: my id: %d, send msgs to detect the physically link between (%d, %d) at line: %d.",	globalMyID, node1[j],  node2[j], __LINE__);
		outputMsg(buffer);
		outputPathRoute(pTmpPathRoute, 1);

		// Send the path route even if is down.
		memcpy(sendBuf + 6, pTmpPathRoute, sizeof(PathRoute));
		sendMsg(node2[j], sendBuf, 6 + sizeof(PathRoute));
	}
}

void sendMsgToDetectThePhysicalLink()
{
	PathRoute *pTmpPathRoute = (PathRoute *)malloc(sizeof(PathRoute));
	if((5 == gTestCaseId) || (6 == gTestCaseId) || (7 == gTestCaseId) || (8 == gTestCaseId))
	{
		sendLinkCheckMsg(pTmpPathRoute, gLinksSrc, gLinksDest);
		sendLinkCheckMsg(pTmpPathRoute, gLinksDest, gLinksSrc);
	}
	free(pTmpPathRoute);
}

void broadcastRouteTable()
{
	PathRoute *pTmpPathRoute = (PathRoute *)malloc(sizeof(PathRoute));

	char sendBuf[6 + sizeof(PathRoute)];
	// 1. message label: 'routes'
	strcpy(sendBuf, "routes");
	pTmpPathRoute->iPathLen = 2;
	pTmpPathRoute->iPath[0] = globalMyID;
	pTmpPathRoute->iCost = 0;
	pTmpPathRoute->msgType = 0;
	// Two places:
	// 1: In the annoucement
	// 2: when to send heart beat
	// We may combine the above, and clear heart beat status when receive any of the above.
	
	pTmpPathRoute->iRouteSequence = globalSequence;
	pTmpPathRoute->iHearBeatSequence = globalHeartBeatSequence++;
	int iDest = 0;

	for(int j = 0; j < globalNeiboursCnt; j++)
	{
		// If the dest is not active, no need to notify it
		iDest = globalNeibours[j];
		
		if(iDest != globalMyID) //(although with a real broadcast you would also get the packet yourself)
		{
			pTmpPathRoute->iPath[1] = iDest;
			pTmpPathRoute->iCost = globalCosts[iDest];
			//sprintf(buffer, "broadc: Cost to be sent in broadcastRouteTable(): dest_%d with code = [%d].\n", iDest, globalCosts[iDest]);
			//outputMsg(buffer);

			if (gDbg & gDbgRoute)
			{
				//sprintf(buffer, "broadc: broadcast the route.");
				//outputMsg(buffer);
				//outputPathRoute(pTmpPathRoute);
			}

			// Send the path route even if is down.
			memcpy(sendBuf + 6, pTmpPathRoute, sizeof(PathRoute));
			sendMsg(iDest, sendBuf, 6 + sizeof(PathRoute));
		}
	}
	free(pTmpPathRoute);
}

void broadcastRouteTable58()
{
	PathRoute *pTmpPathRoute = (PathRoute *)malloc(sizeof(PathRoute));

	char sendBuf[6 + sizeof(PathRoute)];
	// 1. message label: 'routes'
	strcpy(sendBuf, "routes");
	pTmpPathRoute->iPathLen = 2;
	pTmpPathRoute->iPath[0] = globalMyID;
	pTmpPathRoute->iCost = 0;
	pTmpPathRoute->msgType = 0;
	// Two places:
	// 1: In the annoucement
	// 2: when to send heart beat
	// We may combine the above, and clear heart beat status when receive any of the above.
	
	pTmpPathRoute->iRouteSequence = globalSequence;
	pTmpPathRoute->iHearBeatSequence = globalHeartBeatSequence++;
	int iDest = 0;

	for(int j = 0; j < globalForwardNeiboursCnt; j++)
	{
		// If the dest is not active, no need to notify it
		iDest = globalForwardNeibours[j];
		
		if(iDest != globalMyID) //(although with a real broadcast you would also get the packet yourself)
		{
			pTmpPathRoute->iPath[1] = iDest;
			pTmpPathRoute->iCost = globalCosts[iDest];
			//sprintf(buffer, "broadc: Cost to be sent in broadcastRouteTable(): dest_%d with code = [%d].\n", iDest, globalCosts[iDest]);
			//outputMsg(buffer);

			if (gDbg & gDbgRoute)
			{
				//sprintf(buffer, "broadc: broadcast the route.");
				//outputMsg(buffer);
				//outputPathRoute(pTmpPathRoute);
			}

			// Send the path route even if is down.
			memcpy(sendBuf + 6, pTmpPathRoute, sizeof(PathRoute));
			sendMsg(iDest, sendBuf, 6 + sizeof(PathRoute));
		}
	}
	free(pTmpPathRoute);
}

void outputRouteTable(RouteTable  * pRoutingTable,  int isSent)
{
	sprintf(buffer, "RoutingTable Info: Myid_%d isSend: %d, cost: %d, seq: %d", globalMyID, isSent, pRoutingTable->iRouteCosts, pRoutingTable->iSeq);
	outputMsg(buffer);
}

void broadcastRouteTable()
{
	sprintf(buffer, "broadcastRouteTable() has been called.");
	outputMsg(buffer);

	routeTableNeedUpdate = 0;
	int len = 6 + sizeof(RouteTableDV);
	char sendBuf[len];

	strcpy(sendBuf, "routes");
	outputRouteTableDV(&globalLocalRouteTable, 1);

	memcpy(sendBuf + 6, &globalLocalRouteTable, sizeof(RouteTableDV));

	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		if (i != globalMyID)
		{
			sendto(globalSocketUDP, sendBuf, len, 0,
				  (struct sockaddr*)&globalNodeAddrs[i], sizeof(globalNodeAddrs[i]));
		}
	}
}


/*
 * 11 detects DOWN! i=66 : last heard '3103' msecond(s) ago!
 * 66 detects DOWN! i=11 : last heard '3907' msecond(s) ago!
 * Need to notify all the nodes. This dest is not available.
 */
 int removePath(PathRoute* pPathRoute);
 void cancelRouteTable(int iRealDest)
 {
	PathRoute *pTmpPathRoute = (PathRoute *)malloc(sizeof(PathRoute));
	fprintf(stderr, "broad remove : to dest_%d.\n", iRealDest);
	sprintf(buffer, "broad remove: to dest_%d.", iRealDest);
	outputMsg(buffer);

	char sendBuf[6 + sizeof(PathRoute)];
	// 1. message label: 'routes'
	strcpy(sendBuf, "routes");
	pTmpPathRoute->iPathLen = 3;
	pTmpPathRoute->iPath[0] = iRealDest;
	pTmpPathRoute->iPath[1] = globalMyID;
	pTmpPathRoute->iCost = 0;
	pTmpPathRoute->msgType = 123;
	
	// Two places:
	// 1: In the annoucement
	// 2: when to send heart beat
	// We may combine the above, and clear heart beat status when receive any of the above.

	pTmpPathRoute->iRouteSequence = globalSequence;
	pTmpPathRoute->iHearBeatSequence = globalHeartBeatSequence++;

	// Need to delete all the local path first, then forward to other dest
	updateCancel(pTmpPathRoute);

	for(int j = 0; j < globalNeiboursCnt; j++)
	{
		// If the dest is not active, no need to notify it
		int iDest = globalNeibours[j];

		if((iDest != globalMyID) && (iDest != iRealDest)) //(although with a real broadcast you would also get the packet yourself)
		{
			pTmpPathRoute->iPath[2] = iDest;
			pTmpPathRoute->iCost = 0;
			//sprintf(buffer, "broadc: Cost to be sent in broadcastRouteTable(): dest_%d with code = [%d].\n", iDest, globalCosts[iDest]);
			//outputMsg(buffer);

			if (1)
			{
				sprintf(buffer, "Line: %d :FRD: remove : myid: %d, broad cancel: broadcast the route len: %d, [%d, %d, %d].", 
					__LINE__, globalMyID, 
					pTmpPathRoute->iPathLen, 
					pTmpPathRoute->iPath[0], pTmpPathRoute->iPath[1], pTmpPathRoute->iPath[2]);
				outputMsg(buffer);
				outputPathRoute(pTmpPathRoute, 1);
				//fprintf(stderr, "Line: %d, myid: %d, broad cancel: broadcast the route len: %d, 0->: %d, 1->: %d.\n", __LINE__, globalMyID, pTmpPathRoute->iPathLen, pTmpPathRoute->iPath[0], pTmpPathRoute->iPath[1]);
			}

			// Send the path route even if is down.		
			memcpy(sendBuf + 6, pTmpPathRoute, sizeof(PathRoute));
			sendMsg(iDest, sendBuf, 6 + sizeof(PathRoute));

		}
	}
	free(pTmpPathRoute);
}
 
int doesExist(int iDest, PathRoute *pPathRoute) 
{
	for (int j = 0; j < pPathRoute->iPathLen; j++) 
	{
		if (pPathRoute->iPath[j] == iDest)
		{
			return 1;
		}
	}
	return 0;
}

// just for forward purpose
// isUpdated - 0: cancel, 1: update / add
void forwardRouteTable(PathRoute *pPathRoute, int isUpdated) {
	char sendBuf[6 + sizeof(PathRoute)];

	PathRoute *pTmpPathRoute = (PathRoute *)malloc(sizeof(PathRoute));
	// message label: 'routes'
	strcpy(sendBuf, "routes");

	if (gDbg & gDbgRoute)
	{
		//sprintf(buffer, "forwardR: Begin to forward the route for dest_%d. Line: %d", pPathRoute->iPath[0], __LINE__);
		//outputMsg(buffer);
	}

	// Prepare to forward to all the possible dest. Can move it out, as it is common
	for(int j = 0; j < pPathRoute->iPathLen; j++)
	{
		pTmpPathRoute->iPath[j] = pPathRoute->iPath[j];
	}
	pTmpPathRoute->iPathLen = pPathRoute->iPathLen + 1;
	pTmpPathRoute->iRouteSequence = pPathRoute->iRouteSequence;
	pTmpPathRoute->iHearBeatSequence = pPathRoute->iHearBeatSequence;
	pTmpPathRoute->msgType = pPathRoute->msgType;
	// Forward to all the dest
	int iDest = 0;
	for(int j = 0; j < globalNeiboursCnt; j++)
	{
		iDest = globalNeibours[j];

		if (doesExist(iDest, pPathRoute)) {
			if (gDbg & gDbgRoute)
			{
				//sprintf(buffer, "forwardR: Will NOT forward the route to %d, as the dest is in the loop already.", iDest);
				//outputMsg(buffer);
			}
			continue;
		}

		pTmpPathRoute->iPath[pPathRoute->iPathLen] = iDest;
		pTmpPathRoute->iCost = pPathRoute->iCost + globalCosts[iDest];
		//sprintf(buffer, "forwardR: Begin to forward the route to the dest_%d with total %d", iDest, pTmpPathRoute->iCost);
		//outputMsg(buffer);

		if (gDbg & gDbgRoute)
		{
			//sprintf(buffer, "forwardR: forward the following route to dest [%d].", iDest);
			//outputMsg(buffer);
			//outputPathRoute(pTmpPathRoute);
		}

		// Really Send the path route even if is down.
		memcpy(sendBuf + 6, pTmpPathRoute, sizeof(PathRoute));
		sendMsg(iDest, sendBuf, 6 + sizeof(PathRoute));

		if (gDbg & gDbgRoute)
		{
			//sprintf(buffer, "forwardR: End to forward the route. Line: %d", __LINE__);
			//outputMsg(buffer);
		}
	}
	free(pTmpPathRoute);
}

// ********* orig function *************
void* announceToNeighbors(void* unusedParam)
{
	struct timespec sleepFor;
	sleepFor.tv_sec = 0;
	sleepFor.tv_nsec = 300 * 1000 * 1000; //300 ms
	int cnt = 0;

	while(1)
	{
		//sprintf(buffer, "********* In announceToNeighbors() cnt: %d", cnt++);
		//outputMsg(buffer);
		// As there are too many nodes, only need to send to the real neibours.
		if((5 == gTestCaseId) || (8 == gTestCaseId))
		{
			broadcastRouteTableDV();
		}
		else
		{
			broadcastRouteTable58();
		}

		// Check the physical links
		sendMsgToDetectThePhysicalLink();
		nanosleep(&sleepFor, 0);
	}
}

void logSend(const char* message, int dest, int nexthop){
	char logLine[512];
	//rintf(stderr, "myid %d: sending packet dest %d nexthop %d message %s\n", globalMyID, dest, nexthop, message);
	sprintf(logLine, "sending packet dest %d nexthop %d message %s\n", dest, nexthop, message);
	fwrite(logLine, 1, strlen(logLine), runingLogFile);
	fflush(runingLogFile);
	outputMsg(logLine);
}

void logForward(const char* message, int dest, int nexthop){
	char logLine[512];
	sprintf(logLine, "forward packet dest %d nexthop %d message %s\n", dest, nexthop, message);
	fwrite(logLine, 1, strlen(logLine), runingLogFile);
	fflush(runingLogFile);
	outputMsg(logLine);
}

void logReceive(const char* message){
	char logLine[512];
	sprintf(logLine, "receive packet message %s\n", message);
	fwrite(logLine, 1, strlen(logLine), runingLogFile);
	fflush(runingLogFile);
	outputMsg(logLine);
}

void logUnreachable(int dest){
	char logLine[512];
	sprintf(logLine, "unreachable dest %d\n", dest);
	fwrite(logLine, 1, strlen(logLine), runingLogFile);
	fflush(runingLogFile);
	outputMsg(logLine);	
}

void sendMsg(int iDest, const char* buf, int length)
{
	sendto(globalSocketUDP, buf, length, 0, (struct sockaddr*) &globalNodeAddrs[iDest], sizeof(struct sockaddr));
	return;
}

int getNextHop(int iDest)
{
	int bestIdx = globalNodeInfo[iDest].iBestIdx;
	if(bestIdx < 0)
	{
		return -1;
	}
	int* path = globalNodeInfo[iDest].iPaths[bestIdx]->iPath;
	int len = globalNodeInfo[iDest].iPaths[bestIdx]->iPathLen;
	int nextHop = path[len - 2];
	if(gDbg & gDbgMsg)
	{
		//outputNodeInfo(&globalNodeInfo[iDest]);
		//sprintf(buffer, "getNextHop: Next hop is [%d]", nextHop);
		//outputMsg(buffer);
	}
	return nextHop;
}

void sendMessage(int iDest, unsigned char * recvBuf, int nBytes) {

	int nextHop = getNextHop(iDest);
	char* message = recvBuf + 6;

	// Not reachable
	if (-1 == nextHop)
	{
		logUnreachable(iDest);
		return;
	}

	logSend(message, iDest, nextHop);
	sendMsg(nextHop, recvBuf, nBytes);
}

void forwardMessage(unsigned short iDest, unsigned char * recvBuf,int nBytes)
{
	char* message = recvBuf + 6;
	int nextHop = getNextHop(iDest);
	if (-1 == nextHop)
	{
		logUnreachable(iDest);
		return;
	}

	logForward(message, iDest, nextHop);
	sendMsg(nextHop, recvBuf, nBytes);
}

int findTheBestPath(int iDest)
{
	PathInfo *pNodePathInfo = NULL;
	int bestIdx = -1;
	int minCost = 99999;

	// For the first loop, we find the min cost
	int cnt = 0;
	for(int i = 0; i < MAX_PATH_NUM; i++)
	{
		pNodePathInfo = globalNodeInfo[iDest].iPaths[i];
		if (pNodePathInfo == NULL)
		{
			continue;
		}
		cnt++;

		if (printDbg(iDest) == 1)
		{
			sprintf(buffer, "Path info: at idx: %d Line: %d", i, __LINE__);
			outputMsg(buffer);
			outputAnArray(pNodePathInfo->iPath, pNodePathInfo->iPathLen);
		}

		// Compare cost
		if(pNodePathInfo->iCost < minCost)
		{
			minCost = pNodePathInfo->iCost;
			bestIdx = i;
			if (printDbg(iDest) == 1)
			{
				sprintf(buffer, "findTheBestPath: dest_%d, i: %d minCost: %d****** Line: %d", iDest, i, minCost, __LINE__);
				outputMsg(buffer);
				outputAnArray(pNodePathInfo->iPath, pNodePathInfo->iPathLen);
			}
		}
	}
	if (printDbg(iDest) == 1)
	{
		sprintf(buffer, "findTheBestPath: dest_%d, minCost: %d, bestIdx: %d, ****** Line: %d", iDest, minCost, bestIdx, __LINE__);
		outputMsg(buffer);
	}

	int minNextHope = MAX_NODE_SIZE;
	int minNodeId = MAX_NODE_SIZE;

	// search again
	for(int i = 0; i < MAX_PATH_NUM; i++)
	{
		pNodePathInfo = globalNodeInfo[iDest].iPaths[i];
		if(pNodePathInfo == NULL)
		{
			continue;
		}
		if((pNodePathInfo->iCost > minCost))
		{
			continue;
		}

		int nextHopIdx = pNodePathInfo->iPathLen - 2;

		// Compare nexthop id
		if(pNodePathInfo->iPath[nextHopIdx] < minNodeId)
		{
			minNodeId = pNodePathInfo->iPath[nextHopIdx];
			bestIdx = i;
			if (printDbg(iDest) == 1)
			{
				sprintf(buffer, "findTheBestPath: dest_%d, i: %d minCost: %d****** Line: %d", iDest, i, minCost, __LINE__);
				outputMsg(buffer);
				outputAnArray(pNodePathInfo->iPath, pNodePathInfo->iPathLen);
			}
		}
	}
	if (printDbg(iDest) == 1)
	{
		sprintf(buffer, "findTheBestPath: dest_%d, minCost: %d, bestIdx: %d, from total: %d****** Line: %d", iDest, minCost, bestIdx, cnt, __LINE__);
		outputMsg(buffer);
	}

	return bestIdx;
}

int findBlankPathLocation(NodeInfo *pNodeInfo, int iDest)
{
	int idx = 0;
	for(int i = 0; i < MAX_PATH_NUM; i++)
	{
		// Find a blank polition to store this path
		if (NULL == pNodeInfo->iPaths[i])
		{
			if (printDbg(iDest) == 1)
			{
				sprintf(buffer, "findBlank: dest_%d i: %d, ****** Line: %d", iDest, i, __LINE__);
				outputMsg(buffer);
			}

			idx = i;
			break;
		}
	}
	return idx;
}

void updateRouteToLocalPaths(PathRoute* pPathRoute)
{
	int iDest = pPathRoute->iPath[0];
	NodeInfo *pNodeInfo = &globalNodeInfo[iDest];
	int bestIdx = pNodeInfo->iBestIdx;

	if (gDbg & gDbgRoute)
	{
	/*
		sprintf(buffer, "updateRouteTo: Begin to updateRoute() for dest_%d. The new path is here Line: %d", iDest,  __LINE__);
		outputMsg(buffer);
		outputPathRoute(pPathRoute);

		sprintf(buffer, "updateRouteTo: The before path for dest_%d ****** Line: %d", iDest,  __LINE__);
		outputMsg(buffer);
		outputNodeInfo(&globalNodeInfo[iDest]);
		*/
	}
	if (printDbg(iDest) == 1)
	{
		sprintf(buffer, "updateRouteTo: The before path for dest_%d ****** Line: %d", iDest,  __LINE__);
		outputMsg(buffer);
		outputNodeInfo(pNodeInfo);
	}

	// Need to add this new path to the paths, which are used for this dest.
	// Step 1: If seq is new, we should add for sure. Should we check it exist already?
	// Firstly, do not consider we have duplicate ones already

	// Step 1: Search a blank location
	int idx = findBlankPathLocation(pNodeInfo, iDest);
	if (printDbg(iDest) == 1)
	{
		sprintf(buffer, "updateRouteTo: idx: %d ****** Line: %d", idx,	__LINE__);
		outputMsg(buffer);
	}

	// Step 2: select the best path
	/*
	if(bestIdx < 0)
	{
		bestIdx = idx;
	}
	else if (pPathRoute->iCost < pNodeInfo->iCost)
	{
		bestIdx = idx;
	}
	pNodeInfo->iBestIdx = bestIdx;
	*/

	// Step 3: create and update a new path
	PathInfo *pPathInfo = (PathInfo *)malloc(sizeof(PathInfo));

	int *path = pPathInfo->iPath;
	for (int i = 0; i < pPathRoute->iPathLen; i++)
	{
		path[i] = pPathRoute->iPath[i];
	}

	pPathInfo->iCost = pPathRoute->iCost;
	pPathInfo->iRouteSequence = pPathRoute->iRouteSequence;
	pPathInfo->iPathLen = pPathRoute->iPathLen;

	//sprintf(buffer, "updateRouteTo: pPathInfo->iCost: %d ****** Line: %d", pPathInfo->iCost,	__LINE__);
	//outputMsg(buffer);

	// Step 4: Store this path
	pNodeInfo->iPaths[idx] = pPathInfo;
	if(pNodeInfo->iCost > pPathRoute->iCost)
	{
		pNodeInfo->iCost = pPathRoute->iCost;
	}
	pNodeInfo->iRouteSequence = pPathInfo->iRouteSequence;

	// To check the best route
	pNodeInfo->iBestIdx = findTheBestPath(iDest);
	if (printDbg(iDest) == 1)
	{
		outputNodeInfo(&globalNodeInfo[iDest]);

		//sprintf(buffer, "updateRouteTo: End of updateRoute() **** ********************** Line: %d", __LINE__);
		//outputMsg(buffer);
	}
}

// 0 -- diff
// 1 -- same
int cmpPath(int* path1,  int *path2, int len)
{
	for(int j = 0; j < len; j++)
	{
		if(path1[j] != path2[j])
		{
			return 0;
		}
	}
	return 1;
}

// len = 2
int checkConnBeglongsPath(int n1, int n2,  int *path, int len)
{
	for(int j = 0; j < len - 1; j++)
	{
		if((path[j] == n1) && (path[j + 1] == n2))
		{
			return 1;
		}
		if((path[j] == n2) && (path[j + 1] == n1))
		{
			return 1;
		}
	}
	return 0;
}

// 0 - not found
// 1 - found
PathInfo * findPath(int iDest, PathRoute* pPathRoute)
{
	if(globalNodeInfo[iDest].iBestIdx < 0)
	{
		return 0;
	}

	PathInfo *pPathInfo = NULL;
	for(int i = 0; i < MAX_PATH_NUM; i++)
	{
		pPathInfo = globalNodeInfo[iDest].iPaths[i];
		if (pPathInfo == NULL)
		{
			continue;
		}

		// Compare cost
		if(pPathInfo->iCost != pPathRoute->iCost)
		{
			continue;
		}

		// Compare path
		if(0 == cmpPath(pPathInfo->iPath, pPathRoute->iPath, pPathRoute->iPathLen))
		{
			continue;
		}
		return pPathInfo;

	}

	return NULL;
}

// 0 - not found
// 1 - found
int removePath(PathRoute* pPathRoute)
{

	int cnt = 0;
	int loop = 0;

	// Need to remove all the paths to all the dest
	int n1 = pPathRoute->iPath[0];
	int n2 = pPathRoute->iPath[1];
	
	//sprintf(buffer, "removePath: ----------------------n1_%d---n2_%d---------globalNeiboursCnt: %d Line: %d", n1, n2, globalNeiboursCnt, __LINE__);
	//outputMsg(buffer);
	outputAllNodeInfo();
	for (int j = 0; j < globalNeiboursCnt; j++)
	{
		int iDest = globalNeibours[j];
		//int iDest = j;
		//if(globalNodeInfo[iDest].iBestIdx < 0)
		{
			//return 0;
		}

		PathInfo *pPathInfo = NULL;
		for(int i = 0; i < MAX_PATH_NUM; i++)
		{

			pPathInfo = globalNodeInfo[iDest].iPaths[i];
			if (pPathInfo == NULL)
			{
				continue;
			}
			loop++;

			if(printDbg(iDest))
			{
				sprintf(buffer, "removePath:---plan to remove the following path: --path_%d--(n1: %d, n2: %d)---Line: %d------", i, n1, n2, __LINE__);
				outputMsg(buffer);
				outputAnArray(pPathInfo->iPath, pPathInfo->iPathLen);
			}

			// Compare path
			if(0 == checkConnBeglongsPath(pPathRoute->iPath[0], pPathRoute->iPath[1], pPathInfo->iPath, pPathInfo->iPathLen))
			{
				if(printDbg(iDest))
				{
					sprintf(buffer, "removePath:---does not meet condition -----------------path_%d-----Line: %d-------", i, __LINE__);
					outputMsg(buffer);
				}
				continue;
			}
			
			// Remove this path
			free(pPathInfo);
			globalNodeInfo[iDest].iPaths[i] = NULL;
			cnt++;
			if(printDbg(iDest))
			{
				sprintf(buffer, "removePath:---------- remove this one successufully------------cnt_%d------Line: %d------", cnt, __LINE__);
				outputMsg(buffer);
			}
		}

		// To update the best route
		globalNodeInfo[iDest].iBestIdx = findTheBestPath(iDest);
		if(printDbg(iDest))
		{
			sprintf(buffer, "removePath:----------------------cnt_%d--loop: %d ----Line: %d------", cnt, loop, __LINE__);
			outputMsg(buffer);
		}

		if(printDbg(iDest))
		{
			sprintf(buffer, "removePath: ----------------------n1_%d---n2_%d----cnt: %d Loop: %d Line: %d", n1, n2, cnt, loop, __LINE__);
			outputMsg(buffer);
		}
	}
	sprintf(buffer, "removePath: ----------------------n1_%d---n2_%d----cnt: %d Loop: %d Line: %d", n1, n2, cnt, loop, __LINE__);
	outputMsg(buffer);
	outputAllNodeInfo();

	return cnt;
}

// int isRemoving = 0;
void updateCancel(PathRoute* pPathRoute)
{
	/*
	if(isRemoving == 0)
	{
		isRemoving = 1;
	}
	else
	{
		sprintf(buffer, "\n\n-----want to focus on------------------------\n");
		outputMsg(buffer);
		return;
	}
	*/

	int iDest = pPathRoute->iPath[0];
	//fprintf(stderr, "***** remove : Line: %d: ***myid: %d, Need to cancel the route map to dest_%d, [%d, %d].\n", __LINE__, globalMyID, iDest, pPathRoute->iPath[0], pPathRoute->iPath[1]);
	outputPathRoute(pPathRoute, 0);
	sprintf(buffer, "\n\n-----------------------------\n");
	outputMsg(buffer);
	sprintf(buffer, "***** Line: %d, before remove : before remove the route[] dest_%d -> neibour_%d.", __LINE__, iDest, pPathRoute->iPath[1]);
	outputMsg(buffer);
	//outputAllNodeInfo();
	sprintf(buffer, "----------------------------------\n\n", __LINE__);
	outputMsg(buffer);

	int cnt = removePath(pPathRoute);
	//fprintf(stderr, "***** Line: %d, after remove :My id: %d, after remove ing %d * [%d, %d]\n", __LINE__, globalMyID, cnt, iDest, pPathRoute->iPath[1]);
	if(cnt > 0)
	{
		sprintf(buffer, "***** remove :My id: %d, after remove ing %d * [%d, %d]\n", globalMyID, cnt, iDest, pPathRoute->iPath[1]);
		outputMsg(buffer);
		//outputAllNodeInfo();

		sprintf(buffer, "------------------------Line: %d----------\n\n", __LINE__);
		outputMsg(buffer);
	}
	else
	{
		sprintf(buffer, "--unable to remove any-------------------Line: %d----------\n\n", __LINE__);
		outputMsg(buffer);
	}
	// Will always forward till the loop or not sent out
	forwardRouteTable(pPathRoute, 0);
}

void updateRouteAdd(PathRoute* pPathRoute) 
{
	int isForwardNeeded = 0;
	int iDest = pPathRoute->iPath[0];

	if (printDbg(iDest) == 1)
	{
		sprintf(buffer, "listen: Rcv a route for dest_%d, Line: %d.", iDest, __LINE__);
		outputMsg(buffer);
		outputPathRoute(pPathRoute, 0);
	}

	// Need to clear heart beart.
	//sprintf(buffer, "updateRoute: Clean heart beat of dest_%d", iDest);
	//outputMsg(buffer);
	// We do not use it here. We have a specific logic to handle heartbeat.
	if(5 != gTestCaseId)
	{
		// Moved to another place / a specific area to do the heartbeat check
		//gettimeofday(&globalLastHeartbeat[iDest], 0);
		//sprintf(buffer, "myid: %d clear hearteat, dest_%d, Line: %d.", globalMyID, iDest, __LINE__);
		//outputMsg(buffer);
	}
	else
	{
		// Moved to another place / a specific area to do the heartbeat check
		// gettimeofday(&globalLastHeartbeat[iDest], 0);
		//sprintf(buffer, "myid: %d clear hearteat, test id: %d  dest_%d, Line: %d.", globalMyID, gTestCaseId, iDest, __LINE__);
		//outputMsg(buffer);
	}

	// If it is not for me, just ignore it.
	if (pPathRoute->iPath[pPathRoute->iPathLen - 1] != globalMyID)
	{
		if(printDbg(iDest))
		{
			sprintf(buffer, "updateRoute: WRONG *not for me******** dest_%d", iDest);
			outputMsg(buffer);
		}

		return;
	}

	// This is required, otherwise, the link may become inactive.
	// We have 2 ways to ensure heartbeat works
	if(pPathRoute->iHearBeatSequence > globalNodeInfo[iDest].iheartBeatSequence)
	{
		globalNodeInfo[iDest].iheartBeatSequence = pPathRoute->iHearBeatSequence;
		isForwardNeeded = 1;
	}

	// Do not care the age, just care it exists already or not.
	/*
	if(pPathRoute->iRouteSequence > globalNodeInfo[iDest].iRouteSequence)
	{
		globalNodeInfo[iDest].iRouteSequence = pPathRoute->iRouteSequence;
		isForwardNeeded = 1;
	}
	else
	{
		sprintf(buffer, "updateRoute: TOO old. No need to update the route for dest_%d", iDest);
		outputMsg(buffer);
		return;
	}
	*/
	if ((pPathRoute->iCost < globalNodeInfo[iDest].iCost))
	{
		isForwardNeeded = 1;
	}

	// Every node has multiple paths. We may select the best one which has the minimum cost.
	// Did not find it, so need to add it
	PathInfo * path = findPath(iDest, pPathRoute);
	if(NULL == path)
	{
		if(printDbg(iDest))
		{
			sprintf(buffer, "Not found the pathRoute for dest_%d", iDest);
			outputMsg(buffer);
		}
		updateRouteToLocalPaths(pPathRoute);
	}
	else
	{
		if(printDbg(iDest))
		{
			sprintf(buffer, "*** found the pathRoute for dest_%d, local seq: %d, remote seq: %d", 
				iDest, path->iRouteSequence, pPathRoute->iRouteSequence);
			outputMsg(buffer);
		}
		// If this is a new version, we may forward. Otherwise, we do not need it.
		// We cannot stop it. It will stop when the new node is in the loop already.
		path->iRouteSequence++;
		/*
		if(path->iRouteSequence < pPathRoute->iRouteSequence + 10)
		{
			path->iRouteSequence++;
			//isForwardNeeded = 1;

			if(printDbg(iDest))
			{
				sprintf(buffer, "line: %d, finally decided to forward dest_%d, local seq: %d, remote seq: %d", __LINE__,
				iDest, path->iRouteSequence, pPathRoute->iRouteSequence);
				outputMsg(buffer);
			}
		}
		else
		{
			// No need to forward, as it is too old
			//isForwardNeeded = 0;
			if(printDbg(iDest))
			{
				sprintf(buffer, "line: %d, finally decided NOT to forward dest_%d, local seq: %d, remote seq: %d", __LINE__,
				iDest, path->iRouteSequence, pPathRoute->iRouteSequence);
				outputMsg(buffer);
			}
		}
		*/
	}

	// If a new heartbeat or a new route, we need to forward
	if(isForwardNeeded)
	{
		if(printDbg(iDest))
		{
			sprintf(buffer, "updateRoute: YES. Need to forward the path for dest_%d.", pPathRoute->iPath[0]);
			outputMsg(buffer);
		}
		forwardRouteTable(pPathRoute, 1);
	}
	else
	{
		if(printDbg(iDest))
		{
			sprintf(buffer, "updateRoute: No need to forward the path for dest_%d.", pPathRoute->iPath[0]);
			outputMsg(buffer);
		}
	}

}

// Add or cancel a route to a dest
int filterHearbeatRcv = 0;
int gLinkRcvChangeSeq = 0;
void updateRoute(PathRoute* pPathRoute) 
{
	if(123 == pPathRoute->msgType)
	{
		sprintf(buffer, "listen: ****Rcv a send:  to cancel Line: %d", __LINE__);
		outputMsg(buffer);
		updateCancel(pPathRoute);
		return;
	}
	else if(321 == pPathRoute->msgType)
	{
		filterHearbeatRcv++;

		globalNodeInfo[pPathRoute->iPath[0]].isActive = 1;

		//if (filterHearbeatRcv == 10)
		{
			filterHearbeatRcv = 0;
			//rintf(stderr, "LinkInfo: myid: %d Rcv a check the links with for the pair (%d, %d)at Line: %d\n", globalMyID, 
				//athRoute->iPath[0], pPathRoute->iPath[1], __LINE__);
			
			//fprintf(stderr, "  %d hearbeat status: %d,  line: %d\n", globalMyID, globalNodeInfo[pPathRoute->iPath[0]].isActive, pPathRoute->iPath[0],  __LINE__);

		}

		sprintf(buffer, "LinkInfo: HeartSeq:%d, RcvSeq: %d myid: %d Rcv a check the links with for the pair (%d, %d)at Line: %d\n", pPathRoute->iHearBeatSequence, gLinkRcvChangeSeq++, globalMyID, 
			pPathRoute->iPath[0], pPathRoute->iPath[1], __LINE__);
		outputMsg(buffer);

		// Clean heartbeat info
		gettimeofday(&globalLastHeartbeat[pPathRoute->iPath[0]], 0);
		return;
	}
	else
	{
		sprintf(buffer, "listen: ****Rcv a send to add / update. Myid:%d to 77 via nexthop[%d] Line: %d", globalMyID, getNextHop(77),  __LINE__);
		outputMsg(buffer);
		updateRouteAdd(pPathRoute);
		return;
	}
}

// Should we update the path? ***********
void updateCost(unsigned short iDest, unsigned int iCost)
{
	sprintf(buffer, "update: Cost update in updateCost(): dest %d: [%d] -> [%d].", iDest, globalCosts[iDest], iCost);
	outputMsg(buffer);
	globalCosts[iDest] = iCost;
}

int needToRecomputeRoute = 0;
void processDVRoute(int heardFrom, char *recvBuf, int bytesRecvd)
{
	//extract route_table
	RouteTable * pRouteTable = (RouteTable *)(recvBuf + 6);
	
	NodeInfo fromNodeInfo = globalNodeInfo[heardFrom];
	RouteTable * oldRouteTable = fromNodeInfo.pRouteTable;
	outputRouteTable(&globalLocalRouteTable, 0);

	if ((NULL != oldRouteTable) && (pRouteTable->iSeq == oldRouteTable->iSeq))
	{
		//already seen this info
		sprintf(buffer, "Done from %d with seq = %d", heardFrom, pRouteTable->iSeq);
		outputMsg(buffer);
		return;
	}
	else
	{
		sprintf(buffer, "Rcv a new route from %d with seq = %d", heardFrom, pRouteTable->iSeq);
		outputMsg(buffer);
	}

	RouteTable * tmpRouteTable = (RouteTable *) malloc(sizeof(RouteTable));
	memcpy(tmpRouteTable, recvBuf + 6, sizeof(RouteTable));
	globalNodeInfo[heardFrom].pRouteTable = tmpRouteTable;
	 
	if (NULL != oldRouteTable)
	{
		free(oldRouteTable);
	}

	needToRecomputeRoute = 1;

}

// ++++++++++++++++++++++++ DV +++++++++++++++++++++
void outputNodeInfoDV()
{
	NodeInfo *pNode;

	sprintf(buffer, "****** %d begin node info**********.", globalMyID);
	outputMsg(buffer);

	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		pNode = globalNodeInfo + i; 
		if ((pNode->iCost == 1) && (-1 == pNode->iDest) && (-1 == globalLocalRouteTable.iRouteCosts[i]) && (!pNode->isActive))
		{
			//continue;
		}
		sprintf(buffer, "%i: cost = %i, iRouteDest = %i, iRouteCost = %i, isActive = %i", i,
			pNode->iCost, pNode->iDest, globalLocalRouteTable.iRouteCosts[i], pNode->isActive);
		outputMsg(buffer);
	}
	sprintf(buffer, "****** done node info**********.");
	outputMsg(buffer);

}

void determineConnectedNodes ()
{
	nConnectedNodes = 0;
	for (int i = 0; i < MAX_NODE_SIZE; i++)
	{
		if (globalNodeInfo[i].isActive) {
			connectedNodes[nConnectedNodes++] = i;
		}
	}
}
void findBestRouteToI(int i, int* pNext_hop_j, int* pMy_cost_i_via_j)
{
	int tmpNextHop = -1;
	int tmpCost = -1;

	// sprintf(buffer, "findBestRouteToI() is called.");
	// outputMsg(buffer);

	// looking for the best route for i, and its cost
	for (int j = 0; j < nConnectedNodes; j++)
	{

		int aConnectedNode = connectedNodes[j];

		RouteTable* pConnectNode_route_table = globalNodeInfo[aConnectedNode].pRouteTable;
		int myCostToConnectedNode= globalNodeInfo[aConnectedNode].iCost;

		int connectNode_route_cost = 99999;
		if (pConnectNode_route_table) {
			connectNode_route_cost = pConnectNode_route_table->iRouteCosts[i];
		}
		else
		{
			continue;
		}

		if (connectNode_route_cost < 0)
		{
			continue;
		}

		//this should not happen but proctect the code anyway
		if (myCostToConnectedNode < 0)
		{
			fprintf(stderr, "***Node %d cost to %d is -1\n", i, aConnectedNode);
			continue;
		}

		int myCost_to_i_via_connectedNode  = myCostToConnectedNode + connectNode_route_cost;

		if (myCost_to_i_via_connectedNode < 0)
		{
			continue;
		}

		if (tmpCost == -1)
		{
			tmpCost=myCost_to_i_via_connectedNode;
			tmpNextHop=aConnectedNode;
		}
		else if (myCost_to_i_via_connectedNode < tmpCost )
		{
			tmpCost=myCost_to_i_via_connectedNode;
			tmpNextHop=aConnectedNode;
		}
	}

	*pNext_hop_j = tmpNextHop;
	*pMy_cost_i_via_j = tmpCost;

}

// 0 - no updatae due to in the middle of another update;
// 1 - successfully updated;
int reComputeRouteTable()
{
	//sprintf(buffer, "reComputeRouteTable() is called.");
	//outputMsg(buffer);

	if (updatingRouteTable)
	{
		//sprintf(buffer, "reComputeRouteTable() is returned.");
		//outputMsg(buffer);
		return 0;
	}

	// start updating route table
	int updatingRouteTable = 1;

	determineConnectedNodes();

	//iterate over globalNodeInfo[]
	for (int i = 0; i < MAX_NODE_SIZE; i++) {
		
		if (i == globalMyID){
			continue;
		}

		NodeInfo *pNodeInfo = &globalNodeInfo[i];

		int my_cost_i_via_j;
		int next_hop_j = -1;
		
		// Store the old values
		int old_next_hop_last = pNodeInfo->iDest;
		int old_my_route_cost_to_i = globalLocalRouteTable.iRouteCosts[i];
			
		findBestRouteToI(i, &next_hop_j, &my_cost_i_via_j);

		// case 1: no route to i found
		if (-1 == next_hop_j)
		{
			pNodeInfo->iDest = -1;
			globalLocalRouteTable.iRouteCosts[i] = -1;

			// value changes detection
			if (old_next_hop_last != pNodeInfo->iDest || 
				old_my_route_cost_to_i != globalLocalRouteTable.iRouteCosts[i] ) 
			{
				routeTableNeedUpdate = 1;
			}
			sprintf(buffer, "No route found!!!");
			outputMsg(buffer);
			continue;
		}

		// If route to i is found
		// assign the next hop
		pNodeInfo->iDest = next_hop_j;
		int my_cost_to_j = globalNodeInfo[next_hop_j].iCost;
		if (my_cost_to_j == -1){
			sprintf(buffer, "nexthop(%d) to %d is -1!!!", next_hop_j, i);
			outputMsg(buffer);
			continue;
		}
	
		// assign the my cost to i
		globalLocalRouteTable.iRouteCosts[i] = my_cost_i_via_j;

		// value changes detection
		if (old_next_hop_last != pNodeInfo->iDest || 
			old_my_route_cost_to_i != globalLocalRouteTable.iRouteCosts[i] ){
			routeTableNeedUpdate = 1;
		}
	}

	if (routeTableNeedUpdate)
	{
		globalLocalRouteTable.iSeq++;
		sprintf(buffer, "RouteTable %d updated!", globalMyID);
		outputMsg(buffer);
		outputNodeInfoDV();
	}

	// end updating route table
	updatingRouteTable = 0;
	return 1;
}

// ********* orig function *************
void listenForNeighbors()
{
	char fromAddr[100];
	struct sockaddr_in theirAddr;
	socklen_t theirAddrLen;
	unsigned char recvBuf[3000];

	int bytesRecvd;
	while(1)
	{
		theirAddrLen = sizeof(theirAddr);
		if ((bytesRecvd = recvfrom(globalSocketUDP, recvBuf, 3000 , 0, 
					(struct sockaddr*)&theirAddr, &theirAddrLen)) == -1)
		{
			perror("connectivity listener: recvfrom failed");
			exit(1);
		}
		
		inet_ntop(AF_INET, &theirAddr.sin_addr, fromAddr, 100);

		sprintf(buffer, "Rcv [%s] at line: %d.", recvBuf, __LINE__);
		outputMsg(buffer);

		short int heardFrom = -1;
		if(strstr(fromAddr, "10.1.1."))
		{
			heardFrom = atoi(strchr(strchr(strchr(fromAddr,'.') + 1,'.') + 1,'.') + 1);

			// Done: this node can consider heardFrom to be directly connected to it; do any such logic now.

			// link status change detection
			int status = globalNodeInfo[heardFrom].isActive;
			globalNodeInfo[heardFrom].isActive = 1;
			if (0 == status)
			{
				needToRecomputeRoute = 1;
			}
			sprintf(buffer, "Process well at line: %d.", __LINE__);
			outputMsg(buffer);

			// Record that we heard from heardFrom just now.
			gettimeofday(&globalLastHeartbeat[heardFrom], 0);

		}
		
		// Is it a packet from the manager? (see mp2 specification for more details)
		// send format: 'send'<4 ASCII bytes>, iDest<net order 2 byte signed>, <some ASCII message>
		if(!strncmp(recvBuf, "send", 4))
		{
			if(gDbg & gDbgMsg)
			{
				// Done send the requested message to the requested destination node
				sprintf(buffer, "listen: ****Rcv a send: %d with bytes = %d", heardFrom, bytesRecvd);
				outputMsg(buffer);
				outputAllNodeInfo();
			}
			sprintf(buffer, "peter_last_step :Received from  a msg : %s at Line: %d.", recvBuf,  __LINE__);
			outputMsg(buffer);	

			// Done to send the requested message to the requested destination node
			unsigned short *piDest = (unsigned short *)(recvBuf + 4);
			unsigned short iDest = ntohs(*piDest);
			
			char* message = recvBuf + 6;
			recvBuf[bytesRecvd] = '\0';
			// If non heart beat & send a msg to a dest
			if (-1 == heardFrom)
			{
				sprintf(buffer, "Received from dest_%d a msg : %s at Line: %d.", iDest, recvBuf,  __LINE__);
				outputMsg(buffer);	
				sendMessage(iDest, recvBuf, bytesRecvd);
			}
			else if (iDest == globalMyID)
			{
				logReceive(message);
			}
			else
			{
				sprintf(buffer, "peter_last_step : Received from dest_%d a msg : %s at Line: %d.", iDest, recvBuf,  __LINE__);
				outputMsg(buffer);	

				forwardMessage(iDest, recvBuf, bytesRecvd);
			}
		}
		//'cost'<4 ASCII bytes>, iDest<net order 2 byte signed> newCost<net order 4 byte signed>
		else if(!strncmp(recvBuf, "cost", 4))
		{
			sprintf(buffer, "Rcv a cost: %d %d", heardFrom, bytesRecvd);
			outputMsg(buffer);
			// Done record the cost change (remember, the link might currently be down! in that case,
			// This is the new cost you should treat it as having once it comes back up.)
			unsigned short *pDestID = (unsigned short *)(recvBuf + 4);
			unsigned int *pNewCost = (unsigned int *)(recvBuf + 6);
			updateCost(ntohs(*pDestID), ntohl(*pNewCost));
			needToRecomputeRoute = 1;
		} else if (bytesRecvd >= 6 && !strncmp(recvBuf, "routes", 6)) {
			sprintf(buffer, "Rcv a route line: %d.", recvBuf, __LINE__);
			outputMsg(buffer);

			if ((5 == gTestCaseId) || (8 == gTestCaseId))
			{
				processDVRoute(heardFrom, recvBuf ,bytesRecvd);
			}
			else
			{
				// extract route_table
				PathRoute * pPathRoute =(PathRoute *)&recvBuf[6];
				updateRoute(pPathRoute);
				sprintf(buffer, "peter_last_step :Received a msg : %s from %d for dest_%d at Line: %d.", recvBuf, pPathRoute->iPath[pPathRoute->iPathLen - 2], pPathRoute->iPath[0],  __LINE__);
				outputMsg(buffer);	
			}
		} else {
			sprintf(buffer, "peter_last_step :listen: ELSE TO DO %s - TO DO File: %s, Line: %d.", recvBuf,  __FILE__, __LINE__);
			outputMsg(buffer);	
		}
		// TODO now check for the various types of packets you use in your own protocol
		// else if(!strncmp(recvBuf, "your other message types", ))
		if (((5 == gTestCaseId) || (8 == gTestCaseId)) && needToRecomputeRoute) {
			while (1 != reComputeRouteTable())
			{
				usleep(10000);
				sprintf(buffer, "Sleep a little while to reComp");
				outputMsg(buffer);
			}
		}
	}
	//(should never reach here)
	close(globalSocketUDP);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define SIGTERM_MSG "SIGTERM received.\n"

void sig_term_handler(int signum, siginfo_t *info, void *ptr)
{
		
	sprintf(buffer, "This is the end of [%d]", globalMyID);
	fprintf(stderr, "This is the end of [%d]", globalMyID);
	outputMsg(buffer);
	fflush(peterLogFile);
	fclose(peterLogFile);
}

void catch_sigterm()
{
    static struct sigaction _sigact;

    memset(&_sigact, 0, sizeof(_sigact));
    _sigact.sa_sigaction = sig_term_handler;
    _sigact.sa_flags = SA_SIGINFO;

    sigaction(SIGTERM, &_sigact, NULL);
}

