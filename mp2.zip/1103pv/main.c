#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "monitor_neighbors.h"

/*
void seg_fault_handler(int sig)
{
    dumpStackTrace(STDERR_FILENO);
    dumpRequest( "seg_fault", 1 );
    exit(1);
}
*/

int main(int argc, char** argv)
{
	char myAddr[100];
	struct sockaddr_in bindAddr;
	//fprintf(stderr, "\n\n ------------ %s ------------------------------ %s, Line: %d\n",argv[1], __FILE__, __LINE__);
	//fprintf(stderr, "\n\nA new thread for a node ....**************** %s, Line: %d\n", __FILE__, __LINE__);
	//debug_stop();

	if(argc != 4)
	{
		fprintf(stderr, "Usage: %s mynodeid initialcostsfile logfile\n\n", argv[0]);
		exit(1);
	}
	//catch_sigterm();
	// Force dump of stack trace when a seg fault occurs
	//signal(SIGSEGV, seg_fault_handler);

	/*
    if (pthread_mutex_init(&lock, NULL) != 0)
    {
        fprintf(stderr, "\n mutex init failed\n");
        return 1;
    }
	*/

	//initialization: get this process's node ID, record what time it is, 
	//and set up our sockaddr_in's for sending to the other nodes.
	globalMyID = atoi(argv[1]);

	prepareLogFile();
	//fprintf(stderr, "\n********A new test case start at line: %d ************.\n", __LINE__);
	//fprintf(stderr, "Main(%s, %s, %s, %s) has been called.", argv[0], argv[1], argv[2], argv[3], argv[4]);
	sprintf(buffer, "Main(%s, %s, %s, %s) has been called.", argv[0], argv[1], argv[2], argv[3], argv[4]);
	outputMsg(buffer);
	// initialization: get this process's node ID, record what time it is, 
	// and set up our sockaddr_in's for sending to the other nodes.

	for(int i = 0; i < MAX_NODE_SIZE; i++)
	{
		gettimeofday(&globalLastHeartbeat[i], 0);
		char tempaddr[100];
		sprintf(tempaddr, "10.1.1.%d", i);
		memset(&globalNodeAddrs[i], 0, sizeof(globalNodeAddrs[i]));
		globalNodeAddrs[i].sin_family = AF_INET;
		globalNodeAddrs[i].sin_port = htons(7777);
		inet_pton(AF_INET, tempaddr, &globalNodeAddrs[i].sin_addr);
	}

	//Done: read and parse initial costs file. default to cost 1 if no entry for a node. file may be empty.
	initCosts();
	initNodes();

	//setup runingLogFile
	setupruningLogFile(argv[3]);
	//read and parse initial costs file. default to cost 1 if no entry for a node. file may be empty.
	processInitCostFile(argv[2]);	

	// topology.txt
	processNeibours();

	sprintf(buffer, "Create a socket.");
	outputMsg(buffer);

	//socket() and bind() our socket. We will do all sendto()ing and recvfrom()ing on this one.
	if((globalSocketUDP = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		fprintf(stderr, "\nFailed to set up socket, File: %s, Line: %d\n", __FILE__, __LINE__);
		perror("socket");
		exit(1);
	}

	sprintf(myAddr, "10.1.1.%d", globalMyID);	
	memset(&bindAddr, 0, sizeof(bindAddr));
	bindAddr.sin_family = AF_INET;
	bindAddr.sin_port = htons(7777);
	inet_pton(AF_INET, myAddr, &bindAddr.sin_addr);

	sprintf(buffer, "Begin to bind.");
	outputMsg(buffer);

	if(bind(globalSocketUDP, (struct sockaddr*)&bindAddr, sizeof(struct sockaddr_in)) < 0)
	{
		fprintf(stderr, "\nFailed to bind %d, File: %s, Line: %d", globalSocketUDP,  __FILE__, __LINE__);
		close(globalSocketUDP);
		exit(1);
	}

	//start threads... feel free to add your own, and to remove the provided ones.
	pthread_t announcerThread;
	pthread_create(&announcerThread, 0, announceToNeighbors, (void*)0);

	pthread_t monitorLinkDownThread;
	pthread_create(&monitorLinkDownThread, 0, monitorLinkDown, (void*)0);
	sprintf(buffer, "Begin to listen to neighbors.");
	outputMsg(buffer);

	// good luck, have fun!
	listenForNeighbors();
	
	printf("peter close my local log file per node id.");
	outputMsg("This is the end");
	fclose(peterLogFile);

	// pthread_mutex_destroy(&lock);
}
